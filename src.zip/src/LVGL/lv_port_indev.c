#include <stdbool.h>
#include <stdint.h>

#include "xparameters.h"
#include "xgpiops.h"
#include "xil_printf.h"

#include "../KEY/key.h"
#include "../USB/usb_mouse.h"

#include "lv_port_indev.h"
#include "lvgl.h"

extern XGpioPs Gpio;
extern lv_indev_t * mouse_indev;
extern lv_obj_t   * mouse_cursor_obj;

/*
 * Initial cursor position: center of 1280x720 screen.
 */
static int32_t g_cursor_x = 640;
static int32_t g_cursor_y = 360;
static bool    g_pressed  = false;

static void pointer_read_cb(lv_indev_t * indev, lv_indev_data_t * data);

#define USB_POINTER_SPEED_NUM       3
#define USB_POINTER_SPEED_DEN       1
#define USB_POINTER_MAX_RAW_DELTA   64
#define USB_POINTER_MAX_STEP        96

#define USB_POINTER_DEBUG           0
#define USB_POINTER_DEBUG_FIRST     32U
#define USB_POINTER_DEBUG_EVERY_N   256U

#define SCREEN_X_MAX                1279
#define SCREEN_Y_MAX                719
#define CURSOR_OBJ_SIZE             12
#define CURSOR_OBJ_RADIUS           (CURSOR_OBJ_SIZE / 2)
#define CURSOR_CENTER_MIN_X         CURSOR_OBJ_RADIUS
#define CURSOR_CENTER_MIN_Y         CURSOR_OBJ_RADIUS
#define CURSOR_CENTER_MAX_X         (SCREEN_X_MAX - CURSOR_OBJ_RADIUS)
#define CURSOR_CENTER_MAX_Y         (SCREEN_Y_MAX - CURSOR_OBJ_RADIUS)
#define CURSOR_OBJ_MAX_X            (SCREEN_X_MAX - CURSOR_OBJ_SIZE + 1)
#define CURSOR_OBJ_MAX_Y            (SCREEN_Y_MAX - CURSOR_OBJ_SIZE + 1)
#define CURSOR_OBJ_UPDATE_INTERVAL_MS 8U

static uint32_t g_usb_pointer_read_count = 0U;

void indev_get_cursor(int32_t *x, int32_t *y)
{
    if (x != NULL) {
        *x = g_cursor_x;
    }

    if (y != NULL) {
        *y = g_cursor_y;
    }
}

void lv_port_indev_init(void)
{
    mouse_indev = lv_indev_create();

    lv_indev_set_type(mouse_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(mouse_indev, pointer_read_cb);
}

static int32_t clamp_i32(int32_t v, int32_t min_v, int32_t max_v)
{
    if (v < min_v) {
        return min_v;
    }

    if (v > max_v) {
        return max_v;
    }

    return v;
}

static int32_t scale_usb_delta(int32_t d)
{
    d = clamp_i32(d, -USB_POINTER_MAX_RAW_DELTA, USB_POINTER_MAX_RAW_DELTA);

    int32_t scaled = (d * USB_POINTER_SPEED_NUM) / USB_POINTER_SPEED_DEN;

    if (d > 0 && scaled <= 0) {
        scaled = 1;
    } else if (d < 0 && scaled >= 0) {
        scaled = -1;
    }

    return clamp_i32(scaled, -USB_POINTER_MAX_STEP, USB_POINTER_MAX_STEP);
}

static void cursor_object_update_position(void)
{
    static int32_t last_obj_x = -1;
    static int32_t last_obj_y = -1;
    static uint32_t last_update_tick = 0U;
    static bool moved_foreground = false;
    static bool pending_update = false;

    if (mouse_cursor_obj == NULL) {
        return;
    }

    /*
     * mouse_cursor_obj is a 12x12 white circle.
     * Use cursor_x/cursor_y as logical center.
     */
    int32_t obj_x = g_cursor_x - CURSOR_OBJ_RADIUS;
    int32_t obj_y = g_cursor_y - CURSOR_OBJ_RADIUS;

    obj_x = clamp_i32(obj_x, 0, CURSOR_OBJ_MAX_X);
    obj_y = clamp_i32(obj_y, 0, CURSOR_OBJ_MAX_Y);

    if (obj_x == last_obj_x && obj_y == last_obj_y && !pending_update) {
        return;
    }

    pending_update = true;

    uint32_t now = lv_tick_get();
    if (last_update_tick != 0U &&
        (now - last_update_tick) < CURSOR_OBJ_UPDATE_INTERVAL_MS) {
        return;
    }

    lv_obj_set_pos(mouse_cursor_obj, obj_x, obj_y);

    if (!moved_foreground) {
        lv_obj_move_foreground(mouse_cursor_obj);
        moved_foreground = true;
    }

    last_obj_x = obj_x;
    last_obj_y = obj_y;
    last_update_tick = now;
    pending_update = false;
}

static bool usb_pointer_consume_and_apply(const char *tag)
{
    usb_mouse_state_t usb_state;

    if (!usb_mouse_get_state(&usb_state)) {
        return false;
    }

    if (usb_state.has_new_data) {
        int32_t dx = scale_usb_delta(usb_state.dx);
        int32_t dy = scale_usb_delta(usb_state.dy);
        bool cursor_moved = ((dx != 0) || (dy != 0));

        /*
         * Touch-style pointer model:
         * - The physical USB mouse is only a touch surrogate.
         * - Left button means finger down.
         * - Pointer motion must continue while pressed so LVGL can drag
         *   buttons, trigger level and waveform objects.
         */
        g_cursor_x += dx;
        g_cursor_y += dy;

        g_cursor_x = clamp_i32(g_cursor_x, CURSOR_CENTER_MIN_X, CURSOR_CENTER_MAX_X);
        g_cursor_y = clamp_i32(g_cursor_y, CURSOR_CENTER_MIN_Y, CURSOR_CENTER_MAX_Y);

        g_usb_pointer_read_count++;

#if USB_POINTER_DEBUG
        if (g_usb_pointer_read_count <= USB_POINTER_DEBUG_FIRST ||
            ((g_usb_pointer_read_count % USB_POINTER_DEBUG_EVERY_N) == 0U) ||
            usb_state.left) {

            xil_printf("%s USB touch #%lu: raw_dx=%ld raw_dy=%ld scaled_dx=%ld scaled_dy=%ld left=%lu pos=(%ld,%ld)\r\n",
                       tag,
                       (unsigned long)g_usb_pointer_read_count,
                       (long)usb_state.dx,
                       (long)usb_state.dy,
                       (long)dx,
                       (long)dy,
                       (unsigned long)(usb_state.left ? 1U : 0U),
                       (long)g_cursor_x,
                       (long)g_cursor_y);
        }
#endif

        if (cursor_moved) {
            cursor_object_update_position();
        }
    }

    g_pressed = usb_state.left;

    return true;
}

void lv_port_indev_process_usb_direct(void)
{
    /*
     * This is called explicitly from main loop and DMA wait loop.
     * It bypasses the problem where LVGL's read_cb is not frequent enough.
     */
    (void)usb_pointer_consume_and_apply("DIRECT");
}

static bool pointer_read_usb_mouse(uint32_t dt)
{
    LV_UNUSED(dt);

    return usb_pointer_consume_and_apply("LVGL");
}

static void pointer_read_key_fallback(uint32_t dt)
{
    const int32_t SPEED_SLOW   = 350;
    const int32_t SPEED_MEDIUM = 800;
    const int32_t SPEED_FAST   = 1400;

    const uint32_t SPEED_MEDIUM_MS = 250;
    const uint32_t SPEED_FAST_MS   = 700;

    const uint32_t CLICK_DEBOUNCE_MS = 30;

    static uint32_t hold_dir_ms = 0;

    static bool click_raw_prev = false;
    static bool click_stable = false;
    static uint32_t click_change_tick = 0;

    uint32_t now = lv_tick_get();

    /*
     * Key mapping:
     *   key0: left
     *   key1: up
     *   key2: down
     *   key3: right
     */
    keys_scan(&Gpio);

    bool k_left_raw  = key_is_pressed(0);
    bool k_up_raw    = key_is_pressed(1);
    bool k_down_raw  = key_is_pressed(2);
    bool k_right_raw = key_is_pressed(3);

    /*
     * key0 + key3 = left click.
     */
    bool click_raw = (k_left_raw && k_right_raw);

    bool k_left  = k_left_raw;
    bool k_up    = k_up_raw;
    bool k_down  = k_down_raw;
    bool k_right = k_right_raw;

    if (click_raw) {
        k_left  = false;
        k_up    = false;
        k_down  = false;
        k_right = false;
    }

    int32_t dir_x = 0;
    int32_t dir_y = 0;

    if (k_left && !k_right) {
        dir_x = -1;
    } else if (k_right && !k_left) {
        dir_x = 1;
    }

    if (k_up && !k_down) {
        dir_y = -1;
    } else if (k_down && !k_up) {
        dir_y = 1;
    }

    bool any_dir = ((dir_x != 0) || (dir_y != 0));

    if (any_dir) {
        if (hold_dir_ms < 60000U) {
            hold_dir_ms += dt;
        }
    } else {
        hold_dir_ms = 0;
    }

    int32_t speed = SPEED_SLOW;

    if (hold_dir_ms >= SPEED_FAST_MS) {
        speed = SPEED_FAST;
    } else if (hold_dir_ms >= SPEED_MEDIUM_MS) {
        speed = SPEED_MEDIUM;
    }

    if (any_dir) {
        int32_t move = (speed * (int32_t)dt) / 1000;

        if (move < 1) {
            move = 1;
        }

        g_cursor_x += dir_x * move;
        g_cursor_y += dir_y * move;
    }

    g_cursor_x = clamp_i32(g_cursor_x, CURSOR_CENTER_MIN_X, CURSOR_CENTER_MAX_X);
    g_cursor_y = clamp_i32(g_cursor_y, CURSOR_CENTER_MIN_Y, CURSOR_CENTER_MAX_Y);

    if (click_raw != click_raw_prev) {
        click_raw_prev = click_raw;
        click_change_tick = now;
    }

    if ((now - click_change_tick) >= CLICK_DEBOUNCE_MS) {
        click_stable = click_raw;
    }

    g_pressed = click_stable;

    cursor_object_update_position();
}

static void pointer_read_cb(lv_indev_t * indev, lv_indev_data_t * data)
{
    LV_UNUSED(indev);

    static uint32_t last_tick = 0;

    uint32_t now = lv_tick_get();

    if (last_tick == 0U) {
        last_tick = now;
    }

    uint32_t dt = now - last_tick;
    last_tick = now;

    if (dt > 50U) {
        dt = 50U;
    }

    if (!pointer_read_usb_mouse(dt)) {
        pointer_read_key_fallback(dt);
    }

    data->point.x = g_cursor_x;
    data->point.y = g_cursor_y;
    data->state   = g_pressed ? LV_INDEV_STATE_PRESSED
                              : LV_INDEV_STATE_RELEASED;
}
