#ifndef LV_PORT_DISP_H_
#define LV_PORT_DISP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

void lv_port_disp_init(void);

#ifdef __cplusplus
}
#endif

#endif /* LV_PORT_DISP_H_ */
