#ifndef LV_PORT_INDEV_H_
#define LV_PORT_INDEV_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

void lv_port_indev_init(void);
void indev_get_cursor(int32_t *x, int32_t *y);

/*
 * Direct USB mouse service.
 * Called from main loop and DMA wait loop so the cursor can move even when
 * LVGL's indev read callback is not being called frequently enough.
 */
void lv_port_indev_process_usb_direct(void);

#ifdef __cplusplus
}
#endif

#endif /* LV_PORT_INDEV_H_ */
