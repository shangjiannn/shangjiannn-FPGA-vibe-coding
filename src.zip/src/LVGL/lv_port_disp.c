#include "lv_port_disp.h"

#include <stdint.h>
#include <string.h>

#include "xil_cache.h"
#include "xil_types.h"
#include "../main.h"

/*
 * LVGL v9 + Zynq framebuffer ��ʾ������
 *
 * �ؼ��޸���
 * 1. ֧�� LV_DRAW_BUF_STRIDE_ALIGN = 32��
 * 2. �� px_map ��ȡÿһ��ʱʹ�� stride�������� area_width * bytes_per_pixel��
 * 3. ֻ flush ʵ������������Ӧ�� framebuffer cache��
 *
 * �����ڳ��ֵ�б��/ͼ����ң�����ԭ�����ԭ flush û���� stride padding��
 */

#ifndef DISP_HOR_RES
#define DISP_HOR_RES            1280U
#endif

#ifndef DISP_VER_RES
#define DISP_VER_RES            720U
#endif

#ifndef FB_BYTES_PER_PIXEL
#define FB_BYTES_PER_PIXEL      3U
#endif

/*
 * LVGL draw buffer ������
 * 16 �и��ȣ�32 ��Ҳ���ԡ�
 */
#define LV_PORT_DISP_BUF_LINES  16U

#if LV_COLOR_DEPTH == 32
#define LV_PORT_LVGL_BYTES_PER_PIXEL  4U
#elif LV_COLOR_DEPTH == 16
#define LV_PORT_LVGL_BYTES_PER_PIXEL  2U
#else
#error "This lv_port_disp.c supports LV_COLOR_DEPTH 16 or 32 only."
#endif

/*
 * �����ɫ�������ˣ��� 1 �ĳ� 0��
 */
#define LV_PORT_COLOR_ORDER_DIRECT    1

/*
 * �Ƿ�ÿ�� flush ��֡ framebuffer cache��
 *
 * 0��ֻ flush ����Σ��ٶȸ��죬�Ƽ���
 * 1����֡ flush��������������㻳�ɾֲ� cache �����������ʱ�򿪡�
 */
#define LV_PORT_FLUSH_FULL_FRAME_CACHE    0

/*
 * 32-byte ���� draw buffer����� Zynq DCache��
 *
 * ע�⣺
 * main.h ����Ҫ����� buffer��
 * ������������ lv_port_disp.c �ڲ���̬ʹ�á�
 */
static uint8_t draw_buf_1[DISP_HOR_RES *
                          LV_PORT_DISP_BUF_LINES *
                          LV_PORT_LVGL_BYTES_PER_PIXEL]
                          __attribute__((aligned(32)));

static uint8_t draw_buf_2[DISP_HOR_RES *
                          LV_PORT_DISP_BUF_LINES *
                          LV_PORT_LVGL_BYTES_PER_PIXEL]
                          __attribute__((aligned(32)));

static lv_display_t *g_disp = NULL;

static UINTPTR align_down_32(UINTPTR v)
{
    return v & ~((UINTPTR)0x1FU);
}

static UINTPTR align_up_32(UINTPTR v)
{
    return (v + 31U) & ~((UINTPTR)0x1FU);
}

static void cache_flush_range_aligned(UINTPTR addr, UINTPTR len)
{
    if (len == 0U) {
        return;
    }

    UINTPTR start = align_down_32(addr);
    UINTPTR end   = align_up_32(addr + len);

    Xil_DCacheFlushRange(start, end - start);
}

static uint32_t lv_port_align_up_u32(uint32_t v, uint32_t align)
{
    if (align <= 1U) {
        return v;
    }

    return (v + align - 1U) & ~(align - 1U);
}

/*
 * ���� LVGL draw buffer ÿһ�е� stride��
 *
 * ��� lv_conf.h �
 *   #define LV_DRAW_BUF_STRIDE_ALIGN 32
 *
 * ��ô stride ��һ������ area_width * bytes_per_pixel��
 * ��һ�����㵱ǰ����б�ƴ��ҵ���Ҫԭ��
 */
static uint32_t lv_port_get_src_stride(uint32_t width)
{
    uint32_t raw_stride = width * LV_PORT_LVGL_BYTES_PER_PIXEL;

#if defined(LV_DRAW_BUF_STRIDE_ALIGN)
    return lv_port_align_up_u32(raw_stride, LV_DRAW_BUF_STRIDE_ALIGN);
#else
    return raw_stride;
#endif
}

static void flush_full_framebuffer_cache(void)
{
    cache_flush_range_aligned((UINTPTR)frame_buffer_addr,
                              (UINTPTR)(DISP_HOR_RES *
                                        DISP_VER_RES *
                                        FB_BYTES_PER_PIXEL));
}

static void disp_flush(lv_display_t *disp,
                       const lv_area_t *area,
                       uint8_t *px_map)
{
    if (area == NULL || px_map == NULL) {
        lv_display_flush_ready(disp);
        return;
    }

    int32_t x1 = area->x1;
    int32_t y1 = area->y1;
    int32_t x2 = area->x2;
    int32_t y2 = area->y2;

    /*
     * ��ȫ����Ļ�⡣
     */
    if (x2 < 0 ||
        y2 < 0 ||
        x1 >= (int32_t)DISP_HOR_RES ||
        y1 >= (int32_t)DISP_VER_RES) {
        lv_display_flush_ready(disp);
        return;
    }

    /*
     * �ü�����Ļ�ڡ�
     */
    if (x1 < 0) {
        x1 = 0;
    }

    if (y1 < 0) {
        y1 = 0;
    }

    if (x2 >= (int32_t)DISP_HOR_RES) {
        x2 = (int32_t)DISP_HOR_RES - 1;
    }

    if (y2 >= (int32_t)DISP_VER_RES) {
        y2 = (int32_t)DISP_VER_RES - 1;
    }

    const uint32_t flush_w = (uint32_t)(x2 - x1 + 1);
    const uint32_t flush_h = (uint32_t)(y2 - y1 + 1);

    /*
     * ԭʼ LVGL area �Ŀ��ȡ�
     * px_map �ǰ���ԭʼ area ����֯�ģ����ǰ��ղü���� x1/y1��
     */
    const uint32_t src_area_w = (uint32_t)(area->x2 - area->x1 + 1);

    /*
     * �ؼ���ʹ�� stride����Ҫֱ�� src_area_w * bpp��
     */
    const uint32_t src_stride = lv_port_get_src_stride(src_area_w);

    const uint32_t src_x_offset = (uint32_t)(x1 - area->x1);
    const uint32_t src_y_offset = (uint32_t)(y1 - area->y1);

    uint8_t *fb = (uint8_t *)frame_buffer_addr;

    for (uint32_t row = 0; row < flush_h; row++) {
        const uint32_t src_row = row + src_y_offset;

        const uint8_t *src = px_map
                           + src_row * src_stride
                           + src_x_offset * LV_PORT_LVGL_BYTES_PER_PIXEL;

        uint8_t *dst = fb
                     + ((((uint32_t)y1 + row) * DISP_HOR_RES + (uint32_t)x1)
                     * FB_BYTES_PER_PIXEL);

        uint8_t *dst_line_start = dst;

#if (LV_COLOR_DEPTH == 32) && (FB_BYTES_PER_PIXEL == 4) && LV_PORT_COLOR_ORDER_DIRECT
        /*
         * Fast path for a true 32-bit framebuffer.
         * This is intentionally compiled only when the PL video path is also
         * 32-bit. Your currently uploaded PL has a 24-bit VDMA MM2S stream, so
         * the active build still uses the RGB888 conversion path below.
         */
        memcpy(dst, src, flush_w * 4U);
#else
        for (uint32_t col = 0; col < flush_w; col++) {

#if LV_COLOR_DEPTH == 32

#if LV_PORT_COLOR_ORDER_DIRECT
            dst[0] = src[0];
            dst[1] = src[1];
            dst[2] = src[2];
#else
            dst[0] = src[2];
            dst[1] = src[1];
            dst[2] = src[0];
#endif

#if FB_BYTES_PER_PIXEL == 4
            dst[3] = src[3];
            dst += 4U;
#else
            dst += 3U;
#endif
            src += 4U;

#elif LV_COLOR_DEPTH == 16

            uint16_t c = (uint16_t)src[0] | ((uint16_t)src[1] << 8);

            uint8_t r = (uint8_t)(((c >> 11) & 0x1F) << 3);
            uint8_t g = (uint8_t)(((c >> 5)  & 0x3F) << 2);
            uint8_t b = (uint8_t)(( c        & 0x1F) << 3);

#if LV_PORT_COLOR_ORDER_DIRECT
            dst[0] = r;
            dst[1] = g;
            dst[2] = b;
#else
            dst[0] = b;
            dst[1] = g;
            dst[2] = r;
#endif

#if FB_BYTES_PER_PIXEL == 4
            dst[3] = 0xFFU;
            dst += 4U;
#else
            dst += 3U;
#endif
            src += 2U;

#endif
        }
#endif

#if LV_PORT_FLUSH_FULL_FRAME_CACHE == 0
        cache_flush_range_aligned((UINTPTR)dst_line_start,
                                  (UINTPTR)(flush_w * FB_BYTES_PER_PIXEL));
#endif
    }

#if LV_PORT_FLUSH_FULL_FRAME_CACHE
    /*
     * ���Զ��ף���֡ flush��
     * ��������²�����򿪣�̫����
     */
    flush_full_framebuffer_cache();
#endif

    lv_display_flush_ready(disp);
}

void lv_port_disp_init(void)
{
    g_disp = lv_display_create(DISP_HOR_RES, DISP_VER_RES);

    /*
     * ��ǿ�� lv_display_set_color_format��
     * �� LVGL �� lv_conf.h �� LV_COLOR_DEPTH ʹ��Ĭ�ϸ�ʽ��
     */
    lv_display_set_flush_cb(g_disp, disp_flush);

    lv_display_set_buffers(g_disp,
                           draw_buf_1,
                           draw_buf_2,
                           sizeof(draw_buf_1),
                           LV_DISPLAY_RENDER_MODE_PARTIAL);
}
