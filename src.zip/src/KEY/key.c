#include "key.h"
#include "xil_printf.h"

key_info_t g_keys[KEY_COUNT] = {
    { KEY0_PIN, true, false },
    { KEY1_PIN, true, false },
    { KEY2_PIN, true, false },
    { KEY3_PIN, true, false },
};

static int KeyGpioInitDone = 0;

void keys_init(XGpioPs *gpio)
{
    int status;
    XGpioPs_Config *GPIOConfigPtr;

    GPIOConfigPtr = XGpioPs_LookupConfig(GPIO_DEVICE_ID);
    if (GPIOConfigPtr == NULL)
    {
        xil_printf("XGpioPs_LookupConfig failed!\r\n");
        return;
    }

    status = XGpioPs_CfgInitialize(gpio, GPIOConfigPtr, GPIOConfigPtr->BaseAddr);
    if (status != XST_SUCCESS)
    {
        xil_printf("XGpioPs_CfgInitialize failed!\r\n");
        return;
    }

    for (int i = 0; i < KEY_COUNT; i++)
    {
        XGpioPs_SetDirectionPin(gpio, g_keys[i].pin, 0);
        XGpioPs_SetOutputEnablePin(gpio, g_keys[i].pin, 0);
    }

    XGpioPs_SetDirectionPin(gpio, LED0_PIN, 1);
    XGpioPs_SetDirectionPin(gpio, LED1_PIN, 1);
    XGpioPs_SetDirectionPin(gpio, LED2_PIN, 1);
    XGpioPs_SetDirectionPin(gpio, LED3_PIN, 1);
    XGpioPs_SetOutputEnablePin(gpio, LED0_PIN, 1);
    XGpioPs_SetOutputEnablePin(gpio, LED1_PIN, 1);
    XGpioPs_SetOutputEnablePin(gpio, LED2_PIN, 1);
    XGpioPs_SetOutputEnablePin(gpio, LED3_PIN, 1);

    KeyGpioInitDone = 1;
}

void keys_scan(XGpioPs *gpio)
{
    if (!KeyGpioInitDone) return;

    for (int i = 0; i < KEY_COUNT; i++) {
        uint32_t level = XGpioPs_ReadPin(gpio, g_keys[i].pin);
        if (g_keys[i].active_low)
            g_keys[i].pressed = (level == 0);  // �͵�ƽ����
        else
            g_keys[i].pressed = (level != 0);  // �ߵ�ƽ����
    }
}

bool key_is_pressed(uint8_t id)
{
    if (id >= KEY_COUNT) return false;
    return g_keys[id].pressed;
}

void update_leds_from_keys(XGpioPs *gpio)
{
    if (!KeyGpioInitDone) return;

    keys_scan(gpio);

    XGpioPs_WritePin(gpio, LED0_PIN, key_is_pressed(0) ? 1 : 0);
    XGpioPs_WritePin(gpio, LED1_PIN, key_is_pressed(1) ? 1 : 0);
    XGpioPs_WritePin(gpio, LED2_PIN, key_is_pressed(2) ? 1 : 0);
    XGpioPs_WritePin(gpio, LED3_PIN, key_is_pressed(3) ? 1 : 0);
}
