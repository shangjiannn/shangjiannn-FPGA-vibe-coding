#include "adda_runtime.h"

#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "xparameters.h"
#include "xuartps_hw.h"
#include "xil_printf.h"
#include "sleep.h"

#include "adda_ctrl.h"
#include "../SCOPE/scope_app.h"

#ifndef ADDA_RUNTIME_ENABLE_UART_COMMANDS
#define ADDA_RUNTIME_ENABLE_UART_COMMANDS 1
#endif

#ifndef ADDA_RUNTIME_ENABLE_HEALTH_MONITOR
#define ADDA_RUNTIME_ENABLE_HEALTH_MONITOR 1
#endif

#ifndef ADDA_RUNTIME_HEALTH_POLL_DIV
#define ADDA_RUNTIME_HEALTH_POLL_DIV 8000U
#endif

#ifndef ADDA_RUNTIME_COOLDOWN_US
#define ADDA_RUNTIME_COOLDOWN_US 300000U
#endif

#ifndef ADDA_RUNTIME_FLUSH_RX
#define ADDA_RUNTIME_FLUSH_RX 1
#endif

#ifndef ADDA_RUNTIME_AUTO_REF_CLK_HZ
#define ADDA_RUNTIME_AUTO_REF_CLK_HZ 1000000000U
#endif

#ifndef ADDA_RUNTIME_AUTO_MAX_SAMPLE_HZ
#define ADDA_RUNTIME_AUTO_MAX_SAMPLE_HZ 100000000U
#endif

#ifndef ADDA_RUNTIME_AUTO_MIN_SAMPLE_HZ
/* AD9643 conversion-rate lower bound; override only after board-level validation. */
#define ADDA_RUNTIME_AUTO_MIN_SAMPLE_HZ 40000000U
#endif

#ifndef ADDA_UART_BASEADDR
#ifdef STDIN_BASEADDRESS
#define ADDA_UART_BASEADDR STDIN_BASEADDRESS
#elif defined(XPAR_PS7_UART_0_BASEADDR)
#define ADDA_UART_BASEADDR XPAR_PS7_UART_0_BASEADDR
#elif defined(XPAR_PS7_UART_1_BASEADDR)
#define ADDA_UART_BASEADDR XPAR_PS7_UART_1_BASEADDR
#elif defined(XPAR_XUARTPS_0_BASEADDR)
#define ADDA_UART_BASEADDR XPAR_XUARTPS_0_BASEADDR
#elif defined(XPAR_XUARTPS_1_BASEADDR)
#define ADDA_UART_BASEADDR XPAR_XUARTPS_1_BASEADDR
#else
#define ADDA_UART_BASEADDR XPAR_XUARTPS_0_BASEADDR
#endif
#endif

#define ADDA_CMD_BUF_LEN 64U

static bool g_runtime_started = false;
static bool g_runtime_test_mode = false;
static bool g_runtime_busy = false;

static u32  g_last_status = 0U;
static u32  g_last_adc_status = 0U;
static u32  g_health_div = 0U;

static char g_cmd_buf[ADDA_CMD_BUF_LEN];
static u32  g_cmd_len = 0U;

static u32 ceil_div_u32(u32 n, u32 d)
{
    if (d == 0U) {
        return 0U;
    }

    return (u32)(((u64)n + (u64)d - 1ULL) / (u64)d);
}

static void adda_runtime_flush_rx(void)
{
#if ADDA_RUNTIME_FLUSH_RX
    int guard = 1024;

    while ((guard-- > 0) && XUartPs_IsReceiveData(ADDA_UART_BASEADDR)) {
        (void)XUartPs_ReadReg(ADDA_UART_BASEADDR, XUARTPS_FIFO_OFFSET);
    }

    g_cmd_len = 0U;
#endif
}

static int adda_runtime_begin_op(char cmd)
{
    if (g_runtime_busy) {
        xil_printf("\r\nADDA: busy, ignore cmd '%c'\r\n", cmd);
        adda_runtime_flush_rx();
        return XST_FAILURE;
    }

    g_runtime_busy = true;
    return XST_SUCCESS;
}

static void adda_runtime_end_op(void)
{
    usleep(ADDA_RUNTIME_COOLDOWN_US);
    adda_runtime_flush_rx();
    g_runtime_busy = false;
}

static void update_scope_rate_label(void)
{
    adda_sample_clock_state_t clk;
    adda_ctrl_get_sample_clock_state(&clk);

    scope_app_set_sample_clock(clk.mode == ADDA_SAMPLE_MODE_CUSTOM,
                               clk.profile_id,
                               clk.custom_d3,
                               clk.custom_d4,
                               (float)clk.measured_sample_clk_hz,
                               clk.fallback_sample_rate_hz);
}

static void print_rate_label(u32 profile)
{
    adda_sample_clock_state_t clk;
    adda_ctrl_get_sample_clock_state(&clk);

#if ADDA_USE_HW_FREQ_METER
    xil_printf("ADDA: mode=%s profile=%u fallback=%u Hz measured_sample_clk=%u Hz active=%u Hz\r\n",
               adda_ctrl_sample_mode_text(clk.mode),
               (unsigned int)profile,
               (unsigned int)clk.fallback_sample_rate_hz,
               (unsigned int)clk.measured_sample_clk_hz,
               (unsigned int)adda_ctrl_current_sample_rate_hz());
#else
    xil_printf("ADDA: mode=%s profile=%u fallback=%u Hz measured_sample_clk=N/A\r\n",
               adda_ctrl_sample_mode_text(clk.mode),
               (unsigned int)profile,
               (unsigned int)clk.fallback_sample_rate_hz);
#endif
}

static void print_short_status(const char *tag)
{
    u32 status = adda_ctrl_read(ADDA_REG_STATUS);
    u32 adc = adda_ctrl_read(ADDA_REG_ADC_STATUS);
    u32 clk = adda_ctrl_read(ADDA_REG_CLOCK_STATUS);
    u32 custom = adda_ctrl_read(ADDA_REG_AD9516_CUSTOM_STATUS);
    u32 profile = adda_ctrl_current_profile();
    adda_sample_clock_state_t sample_clk;
    adda_ctrl_get_sample_clock_state(&sample_clk);

#if ADDA_USE_HW_FREQ_METER
    xil_printf("\r\n[ADDA %s] ST=0x%08x ADC=0x%08x CLK=0x%08x CUSTOM=0x%08x mode=%s prof=%u d3=%u d4=%u test=%d fallback=%uHz meas=%uHz active=%uHz\r\n",
               (tag != NULL) ? tag : "status",
               (unsigned int)status,
               (unsigned int)adc,
               (unsigned int)clk,
               (unsigned int)custom,
               adda_ctrl_sample_mode_text(sample_clk.mode),
               (unsigned int)profile,
               (unsigned int)sample_clk.custom_d3,
               (unsigned int)sample_clk.custom_d4,
               g_runtime_test_mode ? 1 : 0,
               (unsigned int)sample_clk.fallback_sample_rate_hz,
               (unsigned int)sample_clk.measured_sample_clk_hz,
               (unsigned int)adda_ctrl_current_sample_rate_hz());
#else
    xil_printf("\r\n[ADDA %s] ST=0x%08x ADC=0x%08x CLK=0x%08x CUSTOM=0x%08x mode=%s prof=%u d3=%u d4=%u test=%d fallback=%uHz meas=N/A\r\n",
               (tag != NULL) ? tag : "status",
               (unsigned int)status,
               (unsigned int)adc,
               (unsigned int)clk,
               (unsigned int)custom,
               adda_ctrl_sample_mode_text(sample_clk.mode),
               (unsigned int)profile,
               (unsigned int)sample_clk.custom_d3,
               (unsigned int)sample_clk.custom_d4,
               g_runtime_test_mode ? 1 : 0,
               (unsigned int)sample_clk.fallback_sample_rate_hz);
#endif

    xil_printf("  busy=%d err=%d init=%d prof_done=%d prof_err=%d custom_busy=%d custom_done=%d custom_err=%d lock=%d rst=%d idelay=%d valid=%d aligned=%d pat_err=%d\r\n",
               !!(status & ADDA_STATUS_SPI_BUSY),
               !!(status & ADDA_STATUS_SPI_ERROR),
               !!(status & ADDA_STATUS_INIT_DONE),
               !!(status & ADDA_STATUS_CLOCK_PROFILE_DONE),
               !!(status & ADDA_STATUS_CLOCK_PROFILE_ERROR),
               !!(custom & ADDA_AD9516_CUSTOM_STATUS_BUSY),
               !!(custom & ADDA_AD9516_CUSTOM_STATUS_DONE),
               !!(custom & ADDA_AD9516_CUSTOM_STATUS_ERROR),
               !!(status & ADDA_STATUS_CLOCK_LOCKED),
               !!(status & ADDA_STATUS_RESET_DONE),
               !!(adc & ADDA_ADC_STATUS_IDELAY_READY),
               !!(adc & ADDA_ADC_STATUS_SAMPLE_VALID),
               !!(adc & ADDA_ADC_STATUS_DATA_ALIGNED),
               !!(adc & ADDA_ADC_STATUS_PATTERN_ERROR));
}

void adda_runtime_print_help(void)
{
    xil_printf("\r\n========== ADDA runtime commands =========="
               "\r\n  h/?          : help"
               "\r\n  s            : short status"
               "\r\n  d            : full register dump"
               "\r\n  f            : sample_clk meter status"
               "\r\n  g            : scope timebase + calibration debug"
               "\r\n  v            : scope refresh/DMA/LVGL rate debug"
               "\r\n  c            : clear sticky status/pattern error"
               "\r\n  i            : force default init sequence"
               "\r\n  0/1/2/3      : apply fixed profile 0/1/2/3"
               "\r\n  t            : toggle AD9643 test pattern on/off"
               "\r\n  r            : recover default: test pattern off + profile 0"
               "\r\n  w            : disabled for safety; use 0/1/2/3 one by one"
               "\r\n  4/5/6/7/8    : quick custom dividers"
               "\r\n                 4:D3=12 D4=24, 5:D3=14 D4=28, 6:D3=18 D4=36, 7:D3=24 D4=48, 8:D3=32 D4=64"
               "\r\n  9            : reserved/disabled; ignored safely"
               "\r\n  u <d3> <d4>  : custom AD9516 dividers, example: u 16 32"
               "\r\n  x <d3>       : custom D3=d3 and D4=2*d3, example: x 20"
               "\r\n  [ / ]        : select scope active channel C1 / C2"
               "\r\n  o            : toggle scope CH2 display/measure"
               "\r\n  p            : toggle scope trigger source C1/C2"
               "\r\n"
               "\r\nSafety notes:"
               "\r\n  - Do not send repeated bursts like 111111 or 45678."
               "\r\n  - Runtime now flushes extra RX data after any profile/custom operation."
               "\r\n  - Wait for the printed result before sending the next command."
               "\r\n==========================================\r\n");
}

int adda_runtime_apply_profile(u32 profile, bool adc_test_mode_enable)
{
    int status = adda_ctrl_apply_profile(profile, adc_test_mode_enable);
    if (status != XST_SUCCESS) {
        xil_printf("ADDA runtime: apply profile %u failed\r\n", (unsigned int)profile);
        print_short_status("apply failed");
        return status;
    }

    g_runtime_test_mode = adc_test_mode_enable;
    update_scope_rate_label();
    print_rate_label(profile);
    print_short_status("apply done/stable");
    return XST_SUCCESS;
}

static int apply_custom(u32 d3, u32 d4)
{
    int status = adda_ctrl_apply_custom_dividers(d3, d4, g_runtime_test_mode);
    if (status == XST_SUCCESS) {
        update_scope_rate_label();
        print_short_status("custom done/stable");
    } else {
        print_short_status("custom failed");
    }
    return status;
}

int adda_runtime_restore_default(void)
{
    xil_printf("\r\nADDA runtime: restore default profile and disable test pattern\r\n");
    g_runtime_test_mode = false;
    return adda_runtime_apply_profile(ADDA_PROFILE_DEFAULT, false);
}

int adda_runtime_set_sample_rate_nearest(u32 target_hz,
                                         u32 *actual_requested_hz,
                                         u32 *selected_divider)
{
    if (target_hz == 0U) {
        return XST_FAILURE;
    }

    u32 min_div = ceil_div_u32(ADDA_RUNTIME_AUTO_REF_CLK_HZ,
                               ADDA_RUNTIME_AUTO_MAX_SAMPLE_HZ);
    u32 max_div = ADDA_RUNTIME_AUTO_REF_CLK_HZ /
                  ADDA_RUNTIME_AUTO_MIN_SAMPLE_HZ;

    if (min_div < 2U) {
        min_div = 2U;
    }
    if (max_div > 1024U) {
        max_div = 1024U;
    }
    if (max_div < min_div) {
        return XST_FAILURE;
    }

    u32 divider = ceil_div_u32(ADDA_RUNTIME_AUTO_REF_CLK_HZ, target_hz);
    if (divider < min_div) {
        divider = min_div;
    }
    if (divider > max_div) {
        divider = max_div;
    }

    u32 requested_hz = ADDA_RUNTIME_AUTO_REF_CLK_HZ / divider;
    if (actual_requested_hz != NULL) {
        *actual_requested_hz = requested_hz;
    }
    if (selected_divider != NULL) {
        *selected_divider = divider;
    }

    if (adda_runtime_begin_op('A') != XST_SUCCESS) {
        return XST_FAILURE;
    }

    xil_printf("\r\nADDA auto sample-rate: target=%lu Hz, D3=%lu D4=%lu, expected=%lu Hz\r\n",
               (unsigned long)target_hz,
               (unsigned long)divider,
               (unsigned long)(divider * 2U),
               (unsigned long)requested_hz);

    int status = adda_ctrl_apply_custom_total_divider(divider,
                                                      g_runtime_test_mode);
    if (status == XST_SUCCESS) {
        update_scope_rate_label();
        print_short_status("auto rate done/stable");
    } else {
        print_short_status("auto rate failed");
    }

    adda_runtime_end_op();
    return status;
}

void adda_runtime_init(void)
{
    g_runtime_started = true;
    g_runtime_test_mode = false;
    g_runtime_busy = false;
    g_cmd_len = 0U;
    g_last_status = adda_ctrl_read(ADDA_REG_STATUS);
    g_last_adc_status = adda_ctrl_read(ADDA_REG_ADC_STATUS);
    update_scope_rate_label();

    xil_printf("\r\nADDA runtime console enabled. Press 'h' for commands.\r\n");
    print_short_status("boot");
}

static int parse_u32_token(char **pp, u32 *out)
{
    char *p = *pp;
    char *endp;
    unsigned long value;

    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        return -1;
    }

    value = strtoul(p, &endp, 0);
    if (endp == p) {
        return -1;
    }

    *out = (u32)value;
    *pp = endp;
    return 0;
}

static void runtime_handle_single_char(char ch)
{
    switch (ch) {
    case 'h': case 'H': case '?':
        adda_runtime_print_help();
        break;

    case 's': case 'S':
        print_short_status("manual");
        break;

    case 'd': case 'D':
        adda_ctrl_dump("manual dump");
        break;

    case 'f': case 'F':
#if ADDA_USE_HW_FREQ_METER
        xil_printf("\r\nADDA measured sample_clk=%u Hz, raw_count=%u, window=%u, status=0x%08x\r\n",
                   (unsigned int)adda_ctrl_sample_clk_freq_hz(),
                   (unsigned int)adda_ctrl_read(ADDA_REG_SAMPLE_CLK_COUNT),
                   (unsigned int)adda_ctrl_read(ADDA_REG_SAMPLE_CLK_WINDOW),
                   (unsigned int)adda_ctrl_read(ADDA_REG_SAMPLE_CLK_STATUS));
#else
        xil_printf("\r\nADDA: sample_clk meter disabled/untrusted in current PL.\r\n");
        xil_printf("      Use waveform/ILA for now, or enable ADDA_USE_HW_FREQ_METER after PL meter is fixed.\r\n");
#endif
        break;

    case 'g': case 'G':
        scope_app_print_timebase_debug();
        scope_app_print_calibration_debug();
        break;

    case 'v': case 'V':
        scope_app_print_refresh_debug();
        break;

    case '[':
        scope_app_select_channel(SCOPE_CHANNEL_1);
        xil_printf("\r\nSCOPE: active channel C1\r\n");
        break;

    case ']':
        scope_app_select_channel(SCOPE_CHANNEL_2);
        xil_printf("\r\nSCOPE: active channel C2\r\n");
        break;

    case 'o': case 'O':
        scope_app_toggle_channel(SCOPE_CHANNEL_2);
        xil_printf("\r\nSCOPE: toggled CH2\r\n");
        break;

    case 'p': case 'P':
        scope_app_toggle_trigger_source();
        xil_printf("\r\nSCOPE: toggled trigger source\r\n");
        break;

    case 'c': case 'C':
        adda_ctrl_clear_sticky();
        print_short_status("cleared");
        break;

    case 'i': case 'I':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            if (adda_ctrl_start_default_init() == XST_SUCCESS) {
                g_runtime_test_mode = false;
                update_scope_rate_label();
            }
            print_short_status("init");
            adda_runtime_end_op();
        }
        break;

    case '0': case '1': case '2': case '3':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)adda_runtime_apply_profile((u32)(ch - '0'), g_runtime_test_mode);
            adda_runtime_end_op();
        }
        break;

    case '4':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)apply_custom(12U, 24U);
            adda_runtime_end_op();
        }
        break;

    case '5':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)apply_custom(14U, 28U);
            adda_runtime_end_op();
        }
        break;

    case '6':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)apply_custom(18U, 36U);
            adda_runtime_end_op();
        }
        break;

    case '7':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)apply_custom(24U, 48U);
            adda_runtime_end_op();
        }
        break;

    case '8':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)apply_custom(32U, 64U);
            adda_runtime_end_op();
        }
        break;

    case 't': case 'T':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            g_runtime_test_mode = !g_runtime_test_mode;
            (void)adda_runtime_apply_profile(adda_ctrl_current_profile(), g_runtime_test_mode);
            adda_runtime_end_op();
        }
        break;

    case 'r': case 'R':
        if (adda_runtime_begin_op(ch) == XST_SUCCESS) {
            (void)adda_runtime_restore_default();
            adda_runtime_end_op();
        }
        break;

    case 'w': case 'W':
        xil_printf("\r\nADDA: sweep disabled for safety. Use 0/1/2/3 one by one.\r\n");
        break;

    case '9':
        /*
         * Reserved/disabled on purpose.
         * Treat 9 as an immediate command so it never enters the line buffer.
         * This prevents a bare '9' from prefixing later commands and making
         * the console look frozen.
         */
        g_cmd_len = 0U;
        xil_printf("\r\nADDA: command '9' is reserved/disabled. Use 0-3 or 4-8.\r\n");
        break;

    default:
        /*
         * Do not keep unknown single-character commands in the line buffer.
         * A bad key should be harmless.
         */
        g_cmd_len = 0U;
        xil_printf("\r\nADDA runtime: unknown command '%c'. Press 'h'.\r\n", ch);
        break;
    }
}

static void runtime_handle_line(char *line)
{
    char *p = line;

    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        return;
    }

    if (p[1] == '\0') {
        runtime_handle_single_char(p[0]);
        return;
    }

    if (p[0] == 'u' || p[0] == 'U') {
        u32 d3, d4;

        if (adda_runtime_begin_op(p[0]) != XST_SUCCESS) {
            return;
        }

        p++;
        if (parse_u32_token(&p, &d3) != 0 || parse_u32_token(&p, &d4) != 0) {
            xil_printf("\r\nUsage: u <div3> <div4>, example: u 16 32\r\n");
            adda_runtime_end_op();
            return;
        }

        (void)apply_custom(d3, d4);
        adda_runtime_end_op();
        return;
    }

    if (p[0] == 'x' || p[0] == 'X') {
        u32 d3;

        if (adda_runtime_begin_op(p[0]) != XST_SUCCESS) {
            return;
        }

        p++;
        if (parse_u32_token(&p, &d3) != 0) {
            xil_printf("\r\nUsage: x <div3>, example: x 20. This applies D4=2*D3.\r\n");
            adda_runtime_end_op();
            return;
        }

        (void)apply_custom(d3, d3 * 2U);
        adda_runtime_end_op();
        return;
    }

    xil_printf("\r\nADDA runtime: unknown line command '%s'. Press 'h'.\r\n", line);
}

static bool runtime_is_immediate_command(char c)
{
    if ((c >= '0' && c <= '9') ||
        c == 's' || c == 'S' ||
        c == 'd' || c == 'D' ||
        c == 'f' || c == 'F' ||
        c == 'g' || c == 'G' ||
        c == 'v' || c == 'V' ||
        c == '[' || c == ']' ||
        c == 'o' || c == 'O' ||
        c == 'p' || c == 'P' ||
        c == 'c' || c == 'C' ||
        c == 'i' || c == 'I' ||
        c == 't' || c == 'T' ||
        c == 'r' || c == 'R' ||
        c == 'w' || c == 'W' ||
        c == 'h' || c == 'H' ||
        c == '?') {
        return true;
    }

    return false;
}

static void runtime_poll_uart(void)
{
#if ADDA_RUNTIME_ENABLE_UART_COMMANDS
    if (!XUartPs_IsReceiveData(ADDA_UART_BASEADDR)) {
        return;
    }

    /*
     * Process only one command at a time.
     * Reconfiguration commands flush extra RX bytes after they complete.
     */
    u8 ch = (u8)XUartPs_ReadReg(ADDA_UART_BASEADDR, XUARTPS_FIFO_OFFSET);

    if (ch == '\r' || ch == '\n') {
        if (g_cmd_len > 0U) {
            g_cmd_buf[g_cmd_len] = '\0';
            runtime_handle_line(g_cmd_buf);
            g_cmd_len = 0U;
        }
        return;
    }

    if (g_cmd_len == 0U && runtime_is_immediate_command((char)ch)) {
        runtime_handle_single_char((char)ch);
        return;
    }

    if (g_cmd_len < (ADDA_CMD_BUF_LEN - 1U)) {
        g_cmd_buf[g_cmd_len++] = (char)ch;
    } else {
        g_cmd_len = 0U;
        xil_printf("\r\nADDA runtime: command too long, cleared.\r\n");
    }
#endif
}

static void runtime_health_monitor(void)
{
#if ADDA_RUNTIME_ENABLE_HEALTH_MONITOR
    g_health_div++;
    if (g_health_div < ADDA_RUNTIME_HEALTH_POLL_DIV) {
        return;
    }
    g_health_div = 0U;

    u32 status = adda_ctrl_read(ADDA_REG_STATUS);
    u32 adc = adda_ctrl_read(ADDA_REG_ADC_STATUS);

    const u32 status_watch = ADDA_STATUS_SPI_ERROR |
                             ADDA_STATUS_CLOCK_PROFILE_ERROR |
                             ADDA_STATUS_CLOCK_LOCKED |
                             ADDA_STATUS_RESET_DONE;
    const u32 adc_watch = ADDA_ADC_STATUS_IDELAY_READY |
                          ADDA_ADC_STATUS_SAMPLE_VALID |
                          ADDA_ADC_STATUS_DATA_ALIGNED |
                          ADDA_ADC_STATUS_PATTERN_ERROR;

    if (((status ^ g_last_status) & status_watch) != 0U ||
        ((adc ^ g_last_adc_status) & adc_watch) != 0U) {
        print_short_status("changed");
    }

    if ((status & (ADDA_STATUS_SPI_ERROR | ADDA_STATUS_CLOCK_PROFILE_ERROR)) != 0U) {
        print_short_status("error");
    }

    g_last_status = status;
    g_last_adc_status = adc;
#endif
}

void adda_runtime_poll(void)
{
    if (!g_runtime_started) {
        return;
    }

    runtime_poll_uart();
    runtime_health_monitor();
}
