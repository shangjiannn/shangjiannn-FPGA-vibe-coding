#include "xil_io.h"
#include "xil_printf.h"
#include "sleep.h"
#include "adda_regs.h"

#define ADDA_POLL_TIMEOUT 1000000U

static inline u32 adda_read(u32 offset)
{
    return Xil_In32(ADDA_BASEADDR + offset);
}

static inline void adda_write(u32 offset, u32 value)
{
    Xil_Out32(ADDA_BASEADDR + offset, value);
}

static int adda_wait_status_set(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_read(ADDA_REG_STATUS);
        if ((status & mask) == mask) {
            return 0;
        }
        usleep(10);
    }

    return -1;
}

static int adda_wait_status_clear(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_read(ADDA_REG_STATUS);
        if ((status & mask) == 0U) {
            return 0;
        }
        usleep(10);
    }

    return -1;
}

static void adda_dump_regs(const char *tag)
{
    u32 status = adda_read(ADDA_REG_STATUS);
    u32 adc_status = adda_read(ADDA_REG_ADC_STATUS);
    u32 clock_status = adda_read(ADDA_REG_CLOCK_STATUS);
    u32 clock_profile = adda_read(ADDA_REG_CLOCK_PROFILE);

    xil_printf("\r\n========== %s ==========\r\n", tag);
    xil_printf("BASEADDR        0x%08x\r\n", (u32)ADDA_BASEADDR);
    xil_printf("CONTROL         0x%08x\r\n", adda_read(ADDA_REG_CONTROL));
    xil_printf("STATUS          0x%08x\r\n", status);
    xil_printf("DEVICE_SEL      0x%08x\r\n", adda_read(ADDA_REG_DEVICE_SEL));
    xil_printf("SPI_ADDR        0x%08x\r\n", adda_read(ADDA_REG_SPI_ADDR));
    xil_printf("SPI_WDATA       0x%08x\r\n", adda_read(ADDA_REG_SPI_WDATA));
    xil_printf("SPI_RDATA       0x%08x\r\n", adda_read(ADDA_REG_SPI_RDATA));
    xil_printf("CLOCK_PROFILE   0x%08x\r\n", clock_profile);
    xil_printf("ADC_STATUS      0x%08x\r\n", adc_status);
    xil_printf("CLOCK_STATUS    0x%08x\r\n", clock_status);
    xil_printf("DEBUG_STATUS    0x%08x\r\n", adda_read(ADDA_REG_DEBUG_STATUS));
    xil_printf("PATTERN_ERRCNT  0x%08x\r\n", adda_read(ADDA_REG_PATTERN_ERRCNT));
    xil_printf("IDELAY_STATUS   0x%08x\r\n", adda_read(ADDA_REG_IDELAY_STATUS));

    xil_printf("Decoded STATUS: busy=%d err=%d init_done=%d manual_done=%d profile_busy=%d profile_done=%d profile_err=%d clk_lock=%d rst_done=%d\r\n",
               !!(status & ADDA_STATUS_SPI_BUSY),
               !!(status & ADDA_STATUS_SPI_ERROR),
               !!(status & ADDA_STATUS_INIT_DONE),
               !!(status & ADDA_STATUS_MANUAL_DONE),
               !!(status & ADDA_STATUS_CLOCK_PROFILE_BUSY),
               !!(status & ADDA_STATUS_CLOCK_PROFILE_DONE),
               !!(status & ADDA_STATUS_CLOCK_PROFILE_ERROR),
               !!(status & ADDA_STATUS_CLOCK_LOCKED),
               !!(status & ADDA_STATUS_RESET_DONE));

    xil_printf("Decoded ADC: idelay_ready=%d sample_valid=%d test_mode=%d aligned=%d pattern_err=%d errcnt=%lu\r\n",
               !!(adc_status & ADDA_ADC_STATUS_IDELAY_READY),
               !!(adc_status & ADDA_ADC_STATUS_SAMPLE_VALID),
               !!(adc_status & ADDA_ADC_STATUS_TEST_MODE_EN),
               !!(adc_status & ADDA_ADC_STATUS_DATA_ALIGNED),
               !!(adc_status & ADDA_ADC_STATUS_PATTERN_ERROR),
               (unsigned long)((adc_status & ADDA_ADC_STATUS_ERRCNT_MASK) >> ADDA_ADC_STATUS_ERRCNT_SHIFT));

    xil_printf("Applied profile from CLOCK_STATUS = %lu\r\n",
               (unsigned long)((clock_status & ADDA_CLOCK_STATUS_APPLIED_MASK) >> ADDA_CLOCK_STATUS_APPLIED_SHIFT));
}

static void adda_clear_sticky(void)
{
    adda_write(ADDA_REG_CONTROL,
               ADDA_CONTROL_AUTO_INIT_ENABLE |
               ADDA_CONTROL_CLEAR_STICKY);
    usleep(100);
}

static int adda_start_default_init(void)
{
    xil_printf("\r\nStart default AD9516 -> AD9122 -> AD9643 init...\r\n");

    adda_clear_sticky();

    adda_write(ADDA_REG_CONTROL,
               ADDA_CONTROL_AUTO_INIT_ENABLE |
               ADDA_CONTROL_START_DEFAULT_INIT);

    if (adda_wait_status_set(ADDA_STATUS_INIT_DONE, ADDA_POLL_TIMEOUT) != 0) {
        xil_printf("ERROR: default init timeout, STATUS=0x%08x\r\n",
                   adda_read(ADDA_REG_STATUS));
        return -1;
    }

    if (adda_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ERROR: default init SPI error, STATUS=0x%08x\r\n",
                   adda_read(ADDA_REG_STATUS));
        return -1;
    }

    xil_printf("Default init done.\r\n");
    return 0;
}

static int adda_apply_profile(u32 profile, int adc_test_mode_enable)
{
    u32 control = ADDA_CONTROL_AUTO_INIT_ENABLE |
                  ADDA_CONTROL_APPLY_CLOCK_PROFILE;

    if (adc_test_mode_enable) {
        control |= ADDA_CONTROL_ADC_TEST_MODE_EN;
    }

    xil_printf("\r\nApply clock profile %lu, adc_test_mode=%d\r\n",
               (unsigned long)profile,
               adc_test_mode_enable);

    adda_clear_sticky();

    adda_write(ADDA_REG_CLOCK_PROFILE, profile & 0xFU);
    usleep(10);

    adda_write(ADDA_REG_CONTROL, control);

    if (adda_wait_status_clear(ADDA_STATUS_CLOCK_PROFILE_BUSY,
                               ADDA_POLL_TIMEOUT) != 0) {
        xil_printf("ERROR: profile busy timeout, STATUS=0x%08x\r\n",
                   adda_read(ADDA_REG_STATUS));
        return -1;
    }

    u32 status = adda_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_CLOCK_PROFILE_ERROR) {
        xil_printf("ERROR: profile error, STATUS=0x%08x CLOCK_STATUS=0x%08x\r\n",
                   status,
                   adda_read(ADDA_REG_CLOCK_STATUS));
        return -1;
    }

    if ((status & ADDA_STATUS_CLOCK_PROFILE_DONE) == 0U) {
        xil_printf("ERROR: profile done not set, STATUS=0x%08x CLOCK_STATUS=0x%08x\r\n",
                   status,
                   adda_read(ADDA_REG_CLOCK_STATUS));
        return -1;
    }

    xil_printf("Profile %lu apply done.\r\n", (unsigned long)profile);
    return 0;
}

static int adda_select_device(u32 dev)
{
    adda_clear_sticky();
    adda_write(ADDA_REG_DEVICE_SEL, dev);
    usleep(10);

    if (adda_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ERROR: invalid device select %lu, STATUS=0x%08x\r\n",
                   (unsigned long)dev,
                   adda_read(ADDA_REG_STATUS));
        return -1;
    }

    return 0;
}

static int adda_manual_spi_write(u32 dev, u32 addr, u32 data)
{
    xil_printf("\r\nManual SPI write: dev=%lu addr=0x%04lx data=0x%02lx\r\n",
               (unsigned long)dev,
               (unsigned long)addr,
               (unsigned long)data);

    if (adda_select_device(dev) != 0) {
        return -1;
    }

    adda_clear_sticky();

    adda_write(ADDA_REG_SPI_ADDR, addr & 0x1FFFU);
    adda_write(ADDA_REG_SPI_WDATA, data & 0xFFU);
    adda_write(ADDA_REG_SPI_CMD, ADDA_SPI_CMD_MANUAL_WRITE);

    if (adda_wait_status_clear(ADDA_STATUS_SPI_BUSY, ADDA_POLL_TIMEOUT) != 0) {
        xil_printf("ERROR: manual SPI busy timeout, STATUS=0x%08x\r\n",
                   adda_read(ADDA_REG_STATUS));
        return -1;
    }

    u32 status = adda_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ERROR: manual SPI error, STATUS=0x%08x\r\n", status);
        return -1;
    }

    if ((status & ADDA_STATUS_MANUAL_DONE) == 0U) {
        xil_printf("ERROR: manual done not set, STATUS=0x%08x\r\n", status);
        return -1;
    }

    xil_printf("Manual SPI write done.\r\n");
    return 0;
}

static void adda_profile_sweep_test(void)
{
    /*
     * ע�⣺
     * ��ǰ RTL ��� profile 1/2/3 �ܿ��ܻ��Ǹ���Ĭ�ϳ�ʼ������
     * ����������Ե��ǡ�PS -> AXI -> profile FSM -> SPI �طš��Ŀ�����·��
     * ����֤��ʵ ADC �������Ѿ��ı䡣
     */
    xil_printf("\r\n==== Clock profile sweep test ====\r\n");

    for (u32 profile = 0; profile < 4; profile++) {
        if (adda_apply_profile(profile, 0) != 0) {
            xil_printf("Profile %lu failed.\r\n", (unsigned long)profile);
            return;
        }

        adda_dump_regs("after profile apply");
        usleep(500000);
    }

    xil_printf("Clock profile sweep done.\r\n");
}

static void adda_ad9643_pattern_test(void)
{
    xil_printf("\r\n==== AD9643 ramp test pattern test ====\r\n");

    if (adda_apply_profile(ADDA_PROFILE_DEFAULT, 1) != 0) {
        xil_printf("ERROR: enable AD9643 pattern failed.\r\n");
        return;
    }

    usleep(500000);
    adda_dump_regs("AD9643 pattern ON");

    xil_printf("\r\nDisable AD9643 pattern...\r\n");

    if (adda_apply_profile(ADDA_PROFILE_DEFAULT, 0) != 0) {
        xil_printf("ERROR: disable AD9643 pattern failed.\r\n");
        return;
    }

    usleep(500000);
    adda_dump_regs("AD9643 pattern OFF");
}

int adda_adctop_test_main(void)
{
    xil_printf("\r\n========================================\r\n");
    xil_printf(" ADDA / ADCTOP AXI-Lite GP0 Test\r\n");
    xil_printf(" Base Address: 0x%08x\r\n", (u32)ADDA_BASEADDR);
    xil_printf("========================================\r\n");

    adda_dump_regs("power on");

    adda_clear_sticky();

    if (adda_start_default_init() != 0) {
        xil_printf("FATAL: default init failed.\r\n");
        return -1;
    }

    if (adda_select_device(ADDA_DEVICE_AD9643) != 0) {
        xil_printf("FATAL: AD9643 select failed.\r\n");
        return -1;
    }

    adda_dump_regs("after default init");

    adda_profile_sweep_test();

    adda_ad9643_pattern_test();

#if 0
    /*
     * �ֶ� SPI дʾ����Ĭ�Ϲرա�
     * ��Ҫ��ûȷ�ϼĴ�������ǰ�򿪡�
     *
     * ʾ����AD9643 0x000D ��ͨģʽ/����ģʽ�Ĵ�����
     */
    adda_manual_spi_write(ADDA_DEVICE_AD9643, 0x000DU, 0x00U);
#endif

    xil_printf("\r\nADDA / ADCTOP test complete.\r\n");
    return 0;
}
