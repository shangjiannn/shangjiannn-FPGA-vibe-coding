#ifndef ADDA_AXI_SPI_TEST_H
#define ADDA_AXI_SPI_TEST_H

#include "xil_types.h"
#include "adda_regs.h"

int adda_board_init(void);
int adda_adctop_test_main(void);

void adda_dump_regs(const char *tag);
void adda_clear_sticky(void);

int adda_start_default_init(void);
int adda_apply_profile(u32 profile, int adc_test_mode_enable);
int adda_select_device(u32 dev);
int adda_manual_spi_write(u32 dev, u32 addr, u32 data);

int adda_profile_sweep_test(void);
int adda_ad9643_pattern_test(void);

#endif
