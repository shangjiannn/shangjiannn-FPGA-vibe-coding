#ifndef ADDA_RUNTIME_H_
#define ADDA_RUNTIME_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "xil_types.h"

/*
 * Runtime helper for alpha board testing.
 * It is intentionally PS-side only: no PL RTL changes, no DMA/display rewrites.
 */
void adda_runtime_init(void);
void adda_runtime_poll(void);
void adda_runtime_print_help(void);

/* Force profile from code/UI. Also pushes measured/fallback sample clock to scope. */
int adda_runtime_apply_profile(u32 profile, bool adc_test_mode_enable);
int adda_runtime_restore_default(void);
int adda_runtime_set_sample_rate_nearest(u32 target_hz,
                                         u32 *actual_requested_hz,
                                         u32 *selected_divider);

#ifdef __cplusplus
}
#endif

#endif /* ADDA_RUNTIME_H_ */
