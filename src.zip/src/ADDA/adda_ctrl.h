#ifndef ADDA_CTRL_H
#define ADDA_CTRL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "xil_types.h"
#include "xstatus.h"
#include "adda_regs.h"

/*
 * These are UI/measurement labels for the current profile.
 * IMPORTANT: profile 1~3 only become real sample rates after the PL ROM has
 * real AD9516/AD9122/AD9643 register tables for those profiles.
 * Until then, keep them equal to the verified default rate or adjust only for
 * display experiments.
 */
#ifndef ADDA_PROFILE0_SAMPLE_RATE_HZ
#define ADDA_PROFILE0_SAMPLE_RATE_HZ 1000000.0f
#endif

#ifndef ADDA_PROFILE1_SAMPLE_RATE_HZ
#define ADDA_PROFILE1_SAMPLE_RATE_HZ ADDA_PROFILE0_SAMPLE_RATE_HZ
#endif

#ifndef ADDA_PROFILE2_SAMPLE_RATE_HZ
#define ADDA_PROFILE2_SAMPLE_RATE_HZ ADDA_PROFILE0_SAMPLE_RATE_HZ
#endif

#ifndef ADDA_PROFILE3_SAMPLE_RATE_HZ
#define ADDA_PROFILE3_SAMPLE_RATE_HZ ADDA_PROFILE0_SAMPLE_RATE_HZ
#endif

typedef enum {
    ADDA_SAMPLE_PROFILE_DEFAULT = ADDA_PROFILE_DEFAULT,
    ADDA_SAMPLE_PROFILE_LOW     = ADDA_PROFILE_LOW,
    ADDA_SAMPLE_PROFILE_MID     = ADDA_PROFILE_MID,
    ADDA_SAMPLE_PROFILE_HIGH    = ADDA_PROFILE_HIGH
} adda_sample_profile_t;

typedef struct {
    u32 control;
    u32 status;
    u32 device_sel;
    u32 clock_profile;
    u32 adc_status;
    u32 clock_status;
    u32 debug_status;
    u32 pattern_errcnt;
    u32 idelay_status;
} adda_snapshot_t;

u32  adda_ctrl_read(u32 offset);
void adda_ctrl_write(u32 offset, u32 value);

void adda_ctrl_snapshot(adda_snapshot_t *s);
void adda_ctrl_dump(const char *tag);
void adda_ctrl_clear_sticky(void);

int  adda_ctrl_start_default_init(void);
int  adda_ctrl_apply_profile(u32 profile, bool adc_test_mode_enable);
int  adda_ctrl_set_sample_profile(adda_sample_profile_t profile);
int  adda_ctrl_set_ad9643_test_pattern(bool enable);
int  adda_ctrl_select_device(u32 device);
int  adda_ctrl_manual_spi_write(u32 device, u32 addr, u32 data);

float adda_ctrl_profile_sample_rate_hz(u32 profile);
float adda_ctrl_current_sample_rate_hz(void);
u32   adda_ctrl_current_profile(void);

int  adda_ctrl_basic_bringup(void);
int  adda_ctrl_profile_sweep_test(bool return_to_default);
int  adda_ctrl_ad9643_pattern_test(void);

#ifdef __cplusplus
}
#endif

#endif /* ADDA_CTRL_H */
