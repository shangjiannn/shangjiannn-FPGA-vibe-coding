#ifndef ADDA_CTRL_H
#define ADDA_CTRL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "xil_types.h"
#include "xstatus.h"
#include "adda_regs.h"

#ifndef ADDA_PROFILE_SETTLE_US
#define ADDA_PROFILE_SETTLE_US      300000U
#endif

#ifndef ADDA_CUSTOM_SETTLE_US
#define ADDA_CUSTOM_SETTLE_US       300000U
#endif

/*
 * Ƚ measured_sample_clk Ϊжݡ
 * ԭ򣺵ǰ PL ƵʼƻɿPS ֻüĴ״̬жϡ
 */
#ifndef ADDA_USE_HW_FREQ_METER
#define ADDA_USE_HW_FREQ_METER      1
#endif

/*
 * These are UI/measurement labels for the current profile.
 * IMPORTANT: profile 1~3 only become real sample rates after the PL ROM has
 * real AD9516/AD9122/AD9643 register tables for those profiles.
 * Until then, keep them equal to the verified default rate or adjust only for
 * display experiments.
 */
#ifndef ADDA_PROFILE0_SAMPLE_RATE_HZ
#define ADDA_PROFILE0_SAMPLE_RATE_HZ 100000000.0f
#endif

/*
 * Current true-profile RTL test changes AD9516 LVDS Divider 3/4 only.
 * Relative rate labels assume profile 0 divisor is the verified default,
 * profile 1 is about 10/12 of default, profile 2 about 10/16,
 * profile 3 about 10/20.
 *
 * If you later measure the real sample_clk, change only
 * ADDA_PROFILE0_SAMPLE_RATE_HZ; profile 1~3 will scale automatically.
 */
#ifndef ADDA_PROFILE1_SAMPLE_RATE_HZ
#define ADDA_PROFILE1_SAMPLE_RATE_HZ (ADDA_PROFILE0_SAMPLE_RATE_HZ * (10.0f / 12.0f))
#endif

#ifndef ADDA_PROFILE2_SAMPLE_RATE_HZ
#define ADDA_PROFILE2_SAMPLE_RATE_HZ (ADDA_PROFILE0_SAMPLE_RATE_HZ * (10.0f / 16.0f))
#endif

#ifndef ADDA_PROFILE3_SAMPLE_RATE_HZ
#define ADDA_PROFILE3_SAMPLE_RATE_HZ (ADDA_PROFILE0_SAMPLE_RATE_HZ * (10.0f / 20.0f))
#endif

typedef enum {
    ADDA_SAMPLE_PROFILE_DEFAULT = ADDA_PROFILE_DEFAULT,
    ADDA_SAMPLE_PROFILE_LOW     = ADDA_PROFILE_LOW,
    ADDA_SAMPLE_PROFILE_MID     = ADDA_PROFILE_MID,
    ADDA_SAMPLE_PROFILE_HIGH    = ADDA_PROFILE_HIGH
} adda_sample_profile_t;

typedef enum {
    ADDA_SAMPLE_MODE_PROFILE = 0,
    ADDA_SAMPLE_MODE_CUSTOM  = 1
} adda_sample_mode_t;

typedef struct {
    adda_sample_mode_t mode;
    u32 profile_id;
    u32 custom_d3;
    u32 custom_d4;
    u32 measured_sample_clk_hz;
    float fallback_sample_rate_hz;
} adda_sample_clock_state_t;

typedef struct {
    u32 control;
    u32 status;
    u32 device_sel;
    u32 clock_profile;
    u32 adc_status;
    u32 clock_status;
    u32 debug_status;
    u32 pattern_errcnt;
    u32 idelay_status;
    u32 sample_clk_count;
    u32 sample_clk_status;
    u32 sample_clk_window;
    u32 ad9516_div3_cfg;
    u32 ad9516_div4_cfg;
    u32 ad9516_custom_status;
    u32 ad9516_divider_ratio;
} adda_snapshot_t;


typedef struct {
    u32 x1_div;
    u32 x2_div;
    u32 cfg_word;
} adda_ad9516_div_cfg_t;

u32  adda_ctrl_read(u32 offset);
void adda_ctrl_write(u32 offset, u32 value);

void adda_ctrl_snapshot(adda_snapshot_t *s);
void adda_ctrl_dump(const char *tag);
void adda_ctrl_clear_sticky(void);

int  adda_ctrl_start_default_init(void);
int  adda_ctrl_apply_profile(u32 profile, bool adc_test_mode_enable);
int  adda_ctrl_wait_after_profile(bool adc_test_mode_enable);
int  adda_ctrl_set_sample_profile(adda_sample_profile_t profile);
int  adda_ctrl_set_ad9643_test_pattern(bool enable);
int  adda_ctrl_select_device(u32 device);
int  adda_ctrl_manual_spi_write(u32 device, u32 addr, u32 data);

int  adda_ctrl_apply_custom_dividers(u32 div3, u32 div4, bool adc_test_mode_enable);
int  adda_ctrl_apply_custom_total_divider(u32 total_divider, bool adc_test_mode_enable);
int  adda_ctrl_encode_ad9516_divider(u32 requested_divider, adda_ad9516_div_cfg_t *out_cfg);
u32  adda_ctrl_sample_clk_count(void);
u32  adda_ctrl_sample_clk_freq_hz(void);

float adda_ctrl_profile_sample_rate_hz(u32 profile);
float adda_ctrl_current_fallback_sample_rate_hz(void);
u32   adda_ctrl_current_measured_sample_clk_hz(void);
float adda_ctrl_current_sample_rate_hz(void);
u32   adda_ctrl_current_profile(void);
void  adda_ctrl_get_sample_clock_state(adda_sample_clock_state_t *state);
const char *adda_ctrl_sample_mode_text(adda_sample_mode_t mode);

int  adda_ctrl_basic_bringup(void);
int  adda_ctrl_profile_sweep_test(bool return_to_default);
int  adda_ctrl_ad9643_pattern_test(void);

#ifdef __cplusplus
}
#endif

#endif /* ADDA_CTRL_H */
