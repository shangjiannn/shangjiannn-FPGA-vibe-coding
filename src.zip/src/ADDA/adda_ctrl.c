#include "adda_ctrl.h"

#include "xil_io.h"
#include "xil_printf.h"
#include "sleep.h"
#include <stddef.h>

#define ADDA_POLL_TIMEOUT 1000000U

static u32 g_current_profile = ADDA_PROFILE_DEFAULT;
static adda_sample_mode_t g_sample_mode = ADDA_SAMPLE_MODE_PROFILE;
static u32 g_custom_d3 = 10U;
static u32 g_custom_d4 = 20U;
static bool g_adc_test_mode = false;

u32 adda_ctrl_read(u32 offset)
{
    return Xil_In32(ADDA_BASEADDR + offset);
}

void adda_ctrl_write(u32 offset, u32 value)
{
    Xil_Out32(ADDA_BASEADDR + offset, value);
}

static int wait_status_set(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_ctrl_read(ADDA_REG_STATUS);
        if ((status & mask) == mask) {
            return XST_SUCCESS;
        }
        usleep(10);
    }

    return XST_FAILURE;
}

static int wait_status_clear(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_ctrl_read(ADDA_REG_STATUS);
        if ((status & mask) == 0U) {
            return XST_SUCCESS;
        }
        usleep(10);
    }

    return XST_FAILURE;
}


int adda_ctrl_wait_after_profile(bool adc_test_mode_enable)
{
    const u32 timeout = 3000U;   // 3000 * 1ms = 3s
    u32 i;

    for (i = 0; i < timeout; i++) {
        u32 st  = adda_ctrl_read(ADDA_REG_STATUS);
        u32 adc = adda_ctrl_read(ADDA_REG_ADC_STATUS);

        int init_done = !!(st & ADDA_STATUS_INIT_DONE);
        int spi_idle  = !(st & ADDA_STATUS_SPI_BUSY);
        int no_error  = !(st & ADDA_STATUS_SPI_ERROR);
        int locked    = !!(st & ADDA_STATUS_CLOCK_LOCKED);
        int rst_done  = !!(st & ADDA_STATUS_RESET_DONE);

        int idelay_ok = !!(adc & ADDA_ADC_STATUS_IDELAY_READY);
        int valid     = !!(adc & ADDA_ADC_STATUS_SAMPLE_VALID);
        int aligned   = !!(adc & ADDA_ADC_STATUS_DATA_ALIGNED);

        /*
         * ͨģʽ£Ҫ aligned=1
         * test pattern ģʽ£ǰ checker ȫţǿ aligned=1
         */
        if (init_done && spi_idle && no_error && locked && rst_done &&
            idelay_ok && valid &&
            (adc_test_mode_enable || aligned)) {
            return XST_SUCCESS;
        }

        usleep(1000);
    }

    xil_printf("ADDA WARN: wait stable timeout. ST=0x%08x ADC=0x%08x CLK=0x%08x\r\n",
               adda_ctrl_read(ADDA_REG_STATUS),
               adda_ctrl_read(ADDA_REG_ADC_STATUS),
               adda_ctrl_read(ADDA_REG_CLOCK_STATUS));

    return XST_FAILURE;
}

void adda_ctrl_snapshot(adda_snapshot_t *s)
{
    if (s == NULL) {
        return;
    }

    s->control        = adda_ctrl_read(ADDA_REG_CONTROL);
    s->status         = adda_ctrl_read(ADDA_REG_STATUS);
    s->device_sel     = adda_ctrl_read(ADDA_REG_DEVICE_SEL);
    s->clock_profile  = adda_ctrl_read(ADDA_REG_CLOCK_PROFILE);
    s->adc_status     = adda_ctrl_read(ADDA_REG_ADC_STATUS);
    s->clock_status   = adda_ctrl_read(ADDA_REG_CLOCK_STATUS);
    s->debug_status   = adda_ctrl_read(ADDA_REG_DEBUG_STATUS);
    s->pattern_errcnt = adda_ctrl_read(ADDA_REG_PATTERN_ERRCNT);
    s->idelay_status  = adda_ctrl_read(ADDA_REG_IDELAY_STATUS);
    s->sample_clk_count = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_COUNT);
    s->sample_clk_status = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_STATUS);
    s->sample_clk_window = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_WINDOW);
    s->ad9516_div3_cfg = adda_ctrl_read(ADDA_REG_AD9516_DIV3_CFG);
    s->ad9516_div4_cfg = adda_ctrl_read(ADDA_REG_AD9516_DIV4_CFG);
    s->ad9516_custom_status = adda_ctrl_read(ADDA_REG_AD9516_CUSTOM_STATUS);
    s->ad9516_divider_ratio = adda_ctrl_read(ADDA_REG_AD9516_DIVIDER_RATIO);
}

void adda_ctrl_dump(const char *tag)
{
    adda_snapshot_t s;
    adda_ctrl_snapshot(&s);

    if (tag == NULL) {
        tag = "ADDA";
    }

    xil_printf("\r\n========== %s ==========\r\n", tag);
    xil_printf("BASEADDR        0x%08lx\r\n", (unsigned long)ADDA_BASEADDR);
    xil_printf("CONTROL         0x%08lx\r\n", (unsigned long)s.control);
    xil_printf("STATUS          0x%08lx\r\n", (unsigned long)s.status);
    xil_printf("DEVICE_SEL      0x%08lx\r\n", (unsigned long)s.device_sel);
    xil_printf("CLOCK_PROFILE   0x%08lx\r\n", (unsigned long)s.clock_profile);
    xil_printf("ADC_STATUS      0x%08lx\r\n", (unsigned long)s.adc_status);
    xil_printf("CLOCK_STATUS    0x%08lx\r\n", (unsigned long)s.clock_status);
    xil_printf("DEBUG_STATUS    0x%08lx\r\n", (unsigned long)s.debug_status);
    xil_printf("PATTERN_ERRCNT  0x%08lx\r\n", (unsigned long)s.pattern_errcnt);
    xil_printf("IDELAY_STATUS   0x%08lx\r\n", (unsigned long)s.idelay_status);
    xil_printf("SAMPLE_COUNT    0x%08lx\r\n", (unsigned long)s.sample_clk_count);
    xil_printf("SAMPLE_STATUS   0x%08lx\r\n", (unsigned long)s.sample_clk_status);
    xil_printf("SAMPLE_WINDOW   0x%08lx\r\n", (unsigned long)s.sample_clk_window);
    xil_printf("DIV3_CFG        0x%08lx\r\n", (unsigned long)s.ad9516_div3_cfg);
    xil_printf("DIV4_CFG        0x%08lx\r\n", (unsigned long)s.ad9516_div4_cfg);
    xil_printf("CUSTOM_STATUS   0x%08lx\r\n", (unsigned long)s.ad9516_custom_status);
    xil_printf("DIV_RATIO       0x%08lx\r\n", (unsigned long)s.ad9516_divider_ratio);

    xil_printf("Decoded STATUS: busy=%d err=%d init_done=%d manual_done=%d profile_busy=%d profile_done=%d profile_err=%d clk_lock=%d rst_done=%d\r\n",
               !!(s.status & ADDA_STATUS_SPI_BUSY),
               !!(s.status & ADDA_STATUS_SPI_ERROR),
               !!(s.status & ADDA_STATUS_INIT_DONE),
               !!(s.status & ADDA_STATUS_MANUAL_DONE),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_BUSY),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_DONE),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_ERROR),
               !!(s.status & ADDA_STATUS_CLOCK_LOCKED),
               !!(s.status & ADDA_STATUS_RESET_DONE));

    xil_printf("Decoded ADC: idelay_ready=%d sample_valid=%d test_mode=%d aligned=%d pattern_err=%d errcnt=%lu\r\n",
               !!(s.adc_status & ADDA_ADC_STATUS_IDELAY_READY),
               !!(s.adc_status & ADDA_ADC_STATUS_SAMPLE_VALID),
               !!(s.adc_status & ADDA_ADC_STATUS_TEST_MODE_EN),
               !!(s.adc_status & ADDA_ADC_STATUS_DATA_ALIGNED),
               !!(s.adc_status & ADDA_ADC_STATUS_PATTERN_ERROR),
               (unsigned long)((s.adc_status & ADDA_ADC_STATUS_ERRCNT_MASK) >> ADDA_ADC_STATUS_ERRCNT_SHIFT));

    xil_printf("Applied profile = %lu, fallback_rate = %lu Hz\r\n",
               (unsigned long)((s.clock_status & ADDA_CLOCK_STATUS_APPLIED_MASK) >> ADDA_CLOCK_STATUS_APPLIED_SHIFT),
               (unsigned long)adda_ctrl_current_fallback_sample_rate_hz());

#if ADDA_USE_HW_FREQ_METER
    xil_printf("Measured sample_clk = %lu Hz, active_rate = %lu Hz, raw_count=%lu, window=%lu cycles\r\n",
               (unsigned long)adda_ctrl_sample_clk_freq_hz(),
               (unsigned long)adda_ctrl_current_sample_rate_hz(),
               (unsigned long)s.sample_clk_count,
               (unsigned long)s.sample_clk_window);
#else
    xil_printf("Measured sample_clk = N/A (meter disabled), raw_count=%lu, window=%lu cycles\r\n",
               (unsigned long)s.sample_clk_count,
               (unsigned long)s.sample_clk_window);
#endif
}

void adda_ctrl_clear_sticky(void)
{
    adda_ctrl_write(ADDA_REG_CONTROL,
                    ADDA_CONTROL_AUTO_INIT_ENABLE |
                    (g_adc_test_mode ? ADDA_CONTROL_ADC_TEST_MODE_EN : 0U) |
                    ADDA_CONTROL_CLEAR_STICKY);
    usleep(100);
}

int adda_ctrl_start_default_init(void)
{
    xil_printf("\r\nADDA: start default AD9516 -> AD9122 -> AD9643 init...\r\n");

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_CONTROL,
                    ADDA_CONTROL_AUTO_INIT_ENABLE |
                    (g_adc_test_mode ? ADDA_CONTROL_ADC_TEST_MODE_EN : 0U) |
                    ADDA_CONTROL_START_DEFAULT_INIT);

    if (wait_status_set(ADDA_STATUS_INIT_DONE, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: default init timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    if (adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: default init SPI error, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    g_current_profile = ADDA_PROFILE_DEFAULT;
    g_sample_mode = ADDA_SAMPLE_MODE_PROFILE;
    g_custom_d3 = 10U;
    g_custom_d4 = 20U;
    xil_printf("ADDA: default init done.\r\n");
    return XST_SUCCESS;
}

int adda_ctrl_apply_profile(u32 profile, bool adc_test_mode_enable)
{
    u32 control;

    if (profile > ADDA_PROFILE_HIGH) {
        xil_printf("ADDA ERROR: invalid profile %lu\r\n", (unsigned long)profile);
        return XST_FAILURE;
    }

    g_adc_test_mode = adc_test_mode_enable;

    control = ADDA_CONTROL_AUTO_INIT_ENABLE | ADDA_CONTROL_APPLY_CLOCK_PROFILE;
    if (g_adc_test_mode) {
        control |= ADDA_CONTROL_ADC_TEST_MODE_EN;
    }

    xil_printf("\r\nADDA: apply profile %lu, adc_test_mode=%d\r\n",
               (unsigned long)profile,
               g_adc_test_mode ? 1 : 0);

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_CLOCK_PROFILE, profile & 0xFU);
    usleep(10);
    adda_ctrl_write(ADDA_REG_CONTROL, control);

    if (wait_status_clear(ADDA_STATUS_CLOCK_PROFILE_BUSY, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: profile busy timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    u32 status = adda_ctrl_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_CLOCK_PROFILE_ERROR) {
        xil_printf("ADDA ERROR: profile apply error, STATUS=0x%08lx CLOCK_STATUS=0x%08lx\r\n",
                   (unsigned long)status,
                   (unsigned long)adda_ctrl_read(ADDA_REG_CLOCK_STATUS));
        return XST_FAILURE;
    }

    if ((status & ADDA_STATUS_CLOCK_PROFILE_DONE) == 0U) {
        xil_printf("ADDA ERROR: profile done not set, STATUS=0x%08lx CLOCK_STATUS=0x%08lx\r\n",
                   (unsigned long)status,
                   (unsigned long)adda_ctrl_read(ADDA_REG_CLOCK_STATUS));
        return XST_FAILURE;
    }

    g_current_profile = profile;
    g_sample_mode = ADDA_SAMPLE_MODE_PROFILE;

    usleep(ADDA_PROFILE_SETTLE_US);
    (void)adda_ctrl_wait_after_profile(g_adc_test_mode);

    xil_printf("ADDA: profile %lu apply done, measured=%lu Hz fallback=%lu Hz.\r\n",
               (unsigned long)profile,
               (unsigned long)adda_ctrl_current_measured_sample_clk_hz(),
               (unsigned long)adda_ctrl_current_fallback_sample_rate_hz());
    return XST_SUCCESS;
}

int adda_ctrl_set_sample_profile(adda_sample_profile_t profile)
{
    return adda_ctrl_apply_profile((u32)profile, false);
}

int adda_ctrl_set_ad9643_test_pattern(bool enable)
{
    return adda_ctrl_apply_profile(g_current_profile, enable);
}

int adda_ctrl_select_device(u32 device)
{
    if (device > ADDA_DEVICE_AD9643) {
        return XST_FAILURE;
    }

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_DEVICE_SEL, device);
    usleep(10);

    if (adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: device select failed, device=%lu STATUS=0x%08lx\r\n",
                   (unsigned long)device,
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}

int adda_ctrl_manual_spi_write(u32 device, u32 addr, u32 data)
{
    xil_printf("\r\nADDA: manual SPI write dev=%lu addr=0x%04lx data=0x%02lx\r\n",
               (unsigned long)device,
               (unsigned long)addr,
               (unsigned long)data);

    if (adda_ctrl_select_device(device) != XST_SUCCESS) {
        return XST_FAILURE;
    }

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_SPI_ADDR, addr & 0x1FFFU);
    adda_ctrl_write(ADDA_REG_SPI_WDATA, data & 0xFFU);
    adda_ctrl_write(ADDA_REG_SPI_CMD, ADDA_SPI_CMD_MANUAL_WRITE);

    if (wait_status_clear(ADDA_STATUS_SPI_BUSY, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: manual SPI busy timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    u32 status = adda_ctrl_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: manual SPI error, STATUS=0x%08lx\r\n", (unsigned long)status);
        return XST_FAILURE;
    }

    if ((status & ADDA_STATUS_MANUAL_DONE) == 0U) {
        xil_printf("ADDA ERROR: manual done not set, STATUS=0x%08lx\r\n", (unsigned long)status);
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}


static u8 ad9516_encode_mn_byte(u32 divider)
{
    /* AD9516 divider D = N + M + 2. Keep duty close to 50%. */
    u32 n_cycles;
    u32 m_cycles;
    u32 n;
    u32 m;

    if (divider < 2U) {
        divider = 2U;
    }
    if (divider > 32U) {
        divider = 32U;
    }

    n_cycles = divider / 2U;
    m_cycles = divider - n_cycles;
    if (n_cycles == 0U) {
        n_cycles = 1U;
    }
    if (m_cycles == 0U) {
        m_cycles = 1U;
    }

    n = n_cycles - 1U;
    m = m_cycles - 1U;
    if (n > 15U) {
        n = 15U;
    }
    if (m > 15U) {
        m = 15U;
    }

    return (u8)(((m & 0xFU) << 4) | (n & 0xFU));
}

int adda_ctrl_encode_ad9516_divider(u32 requested_divider, adda_ad9516_div_cfg_t *out_cfg)
{
    u32 best_x1 = 0U;
    u32 best_x2 = 0U;
    u32 best_product = 0U;
    u32 best_error = 0xFFFFFFFFU;

    if (out_cfg == NULL) {
        return XST_FAILURE;
    }

    if (requested_divider < 2U || requested_divider > 1024U) {
        xil_printf("ADDA ERROR: AD9516 divider %lu out of safe range 2..1024\r\n",
                   (unsigned long)requested_divider);
        return XST_FAILURE;
    }

    /* x2=1 means bypass stage 2. x1 must remain 2..32 in this alpha encoding. */
    for (u32 x1 = 2U; x1 <= 32U; ++x1) {
        for (u32 x2 = 1U; x2 <= 32U; ++x2) {
            u32 product = x1 * x2;
            u32 err = (product > requested_divider) ?
                      (product - requested_divider) :
                      (requested_divider - product);
            if (err < best_error) {
                best_error = err;
                best_x1 = x1;
                best_x2 = x2;
                best_product = product;
                if (err == 0U) {
                    break;
                }
            }
        }
        if (best_error == 0U) {
            break;
        }
    }

    out_cfg->x1_div = best_x1;
    out_cfg->x2_div = best_x2;

    /* cfg_word layout matches RTL: [7:0] x1_mn, [15:8] x2_mn,
     * [23:16] control, [31:24] phase/control extension.
     * 0x20 in control bypasses the second cascaded divider, matching the
     * existing known-good profile convention.
     */
    out_cfg->cfg_word = ((u32)0x00U << 24) |
                        ((best_x2 == 1U ? 0x20U : 0x00U) << 16) |
                        ((u32)ad9516_encode_mn_byte(best_x2 == 1U ? 2U : best_x2) << 8) |
                        ((u32)ad9516_encode_mn_byte(best_x1));

    if (best_error != 0U) {
        xil_printf("ADDA WARN: requested divider %lu approximated by %lu = %lu x %lu\r\n",
                   (unsigned long)requested_divider,
                   (unsigned long)best_product,
                   (unsigned long)best_x1,
                   (unsigned long)best_x2);
    }

    return XST_SUCCESS;
}

int adda_ctrl_apply_custom_dividers(u32 div3, u32 div4, bool adc_test_mode_enable)
{
    adda_ad9516_div_cfg_t d3;
    adda_ad9516_div_cfg_t d4;
    u32 status;

    if (adda_ctrl_encode_ad9516_divider(div3, &d3) != XST_SUCCESS ||
        adda_ctrl_encode_ad9516_divider(div4, &d4) != XST_SUCCESS) {
        return XST_FAILURE;
    }

    xil_printf("\r\nADDA: apply custom AD9516 dividers: D3 req=%lu -> %lu x %lu, D4 req=%lu -> %lu x %lu\r\n",
               (unsigned long)div3,
               (unsigned long)d3.x1_div,
               (unsigned long)d3.x2_div,
               (unsigned long)div4,
               (unsigned long)d4.x1_div,
               (unsigned long)d4.x2_div);

    g_adc_test_mode = adc_test_mode_enable;
    adda_ctrl_clear_sticky();

    adda_ctrl_write(ADDA_REG_AD9516_DIV3_CFG, d3.cfg_word);
    adda_ctrl_write(ADDA_REG_AD9516_DIV4_CFG, d4.cfg_word);
    usleep(10);
    adda_ctrl_write(ADDA_REG_AD9516_CUSTOM_CMD, ADDA_AD9516_CUSTOM_CMD_APPLY);

    if (wait_status_clear(ADDA_STATUS_SPI_BUSY, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: custom divider SPI busy timeout, ST=0x%08lx CUSTOM=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS),
                   (unsigned long)adda_ctrl_read(ADDA_REG_AD9516_CUSTOM_STATUS));
        return XST_FAILURE;
    }

    status = adda_ctrl_read(ADDA_REG_AD9516_CUSTOM_STATUS);
    if ((status & ADDA_AD9516_CUSTOM_STATUS_ERROR) != 0U ||
        (status & ADDA_AD9516_CUSTOM_STATUS_DONE) == 0U) {
        xil_printf("ADDA ERROR: custom divider failed, ST=0x%08lx CUSTOM=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS),
                   (unsigned long)status);
        return XST_FAILURE;
    }

    usleep(ADDA_CUSTOM_SETTLE_US);
    (void)adda_ctrl_wait_after_profile(g_adc_test_mode);
    g_sample_mode = ADDA_SAMPLE_MODE_CUSTOM;
    g_custom_d3 = div3;
    g_custom_d4 = div4;
#if ADDA_USE_HW_FREQ_METER
    xil_printf("ADDA: custom divider apply done. measured sample_clk=%lu Hz\r\n",
               (unsigned long)adda_ctrl_sample_clk_freq_hz());
#else
    xil_printf("ADDA: custom divider apply done. measured sample_clk=N/A\r\n");
#endif
    return XST_SUCCESS;
}

int adda_ctrl_apply_custom_total_divider(u32 total_divider, bool adc_test_mode_enable)
{
    /* Keep the relative D4:D3 ratio of the known-good default: D3=10, D4=20.
     * This is useful for quick alpha tests, while the fully manual function
     * above allows independent D3/D4 control.
     */
    return adda_ctrl_apply_custom_dividers(total_divider, total_divider * 2U, adc_test_mode_enable);
}

u32 adda_ctrl_sample_clk_count(void)
{
    return adda_ctrl_read(ADDA_REG_SAMPLE_CLK_COUNT);
}

u32 adda_ctrl_sample_clk_freq_hz(void)
{
#if ADDA_USE_HW_FREQ_METER
    u32 status = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_STATUS);
    u32 count = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_COUNT);
    u32 window = adda_ctrl_read(ADDA_REG_SAMPLE_CLK_WINDOW);
    u64 numerator;

    if ((status & ADDA_SAMPLE_CLK_STATUS_VALID) == 0U || window == 0U) {
        return 0U;
    }

    numerator = (u64)count * (u64)ADDA_AXI_CLK_HZ;
    return (u32)(numerator / (u64)window);
#else
    return 0U;
#endif
}

float adda_ctrl_profile_sample_rate_hz(u32 profile)
{
    switch (profile) {
    case ADDA_PROFILE_DEFAULT:
        return ADDA_PROFILE0_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_LOW:
        return ADDA_PROFILE1_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_MID:
        return ADDA_PROFILE2_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_HIGH:
        return ADDA_PROFILE3_SAMPLE_RATE_HZ;
    default:
        return ADDA_PROFILE0_SAMPLE_RATE_HZ;
    }
}

float adda_ctrl_current_fallback_sample_rate_hz(void)
{
    if (g_sample_mode == ADDA_SAMPLE_MODE_CUSTOM && g_custom_d3 != 0U) {
        return 1000000000.0f / (float)g_custom_d3;
    }

    return adda_ctrl_profile_sample_rate_hz(g_current_profile);
}

u32 adda_ctrl_current_measured_sample_clk_hz(void)
{
    return adda_ctrl_sample_clk_freq_hz();
}

float adda_ctrl_current_sample_rate_hz(void)
{
    u32 measured = adda_ctrl_current_measured_sample_clk_hz();
    if (measured > 0U) {
        return (float)measured;
    }

    return adda_ctrl_current_fallback_sample_rate_hz();
}

u32 adda_ctrl_current_profile(void)
{
    return g_current_profile;
}

void adda_ctrl_get_sample_clock_state(adda_sample_clock_state_t *state)
{
    if (state == NULL) {
        return;
    }

    state->mode = g_sample_mode;
    state->profile_id = g_current_profile;
    state->custom_d3 = g_custom_d3;
    state->custom_d4 = g_custom_d4;
    state->measured_sample_clk_hz = adda_ctrl_current_measured_sample_clk_hz();
    state->fallback_sample_rate_hz = adda_ctrl_current_fallback_sample_rate_hz();
}

const char *adda_ctrl_sample_mode_text(adda_sample_mode_t mode)
{
    switch (mode) {
    case ADDA_SAMPLE_MODE_CUSTOM:
        return "custom";
    case ADDA_SAMPLE_MODE_PROFILE:
    default:
        return "profile";
    }
}

int adda_ctrl_basic_bringup(void)
{
    xil_printf("\r\n========================================\r\n");
    xil_printf(" ADDA / ADCTOP bring-up\r\n");
    xil_printf(" Base Address: 0x%08lx\r\n", (unsigned long)ADDA_BASEADDR);
    xil_printf("========================================\r\n");

    adda_ctrl_dump("power on");
    adda_ctrl_clear_sticky();

    if ((adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_INIT_DONE) == 0U) {
        if (adda_ctrl_start_default_init() != XST_SUCCESS) {
            return XST_FAILURE;
        }
    } else {
        xil_printf("ADDA: auto init already done.\r\n");
    }

    if (adda_ctrl_select_device(ADDA_DEVICE_AD9643) != XST_SUCCESS) {
        return XST_FAILURE;
    }

    adda_ctrl_dump("after ADDA bring-up");
    return XST_SUCCESS;
}

int adda_ctrl_profile_sweep_test(bool return_to_default)
{
    xil_printf("\r\n==== ADDA profile sweep test ====\r\n");

    for (u32 profile = ADDA_PROFILE_DEFAULT; profile <= ADDA_PROFILE_HIGH; profile++) {
        if (adda_ctrl_apply_profile(profile, false) != XST_SUCCESS) {
            return XST_FAILURE;
        }

        adda_ctrl_dump("after profile apply");
        usleep(500000);
    }

    if (return_to_default) {
        if (adda_ctrl_apply_profile(ADDA_PROFILE_DEFAULT, false) != XST_SUCCESS) {
            return XST_FAILURE;
        }
    }

    xil_printf("ADDA: profile sweep done.\r\n");
    return XST_SUCCESS;
}

int adda_ctrl_ad9643_pattern_test(void)
{
    xil_printf("\r\n==== ADDA AD9643 ramp pattern test ====\r\n");

    if (adda_ctrl_set_ad9643_test_pattern(true) != XST_SUCCESS) {
        return XST_FAILURE;
    }
    usleep(500000);
    adda_ctrl_dump("AD9643 pattern ON");

    if (adda_ctrl_set_ad9643_test_pattern(false) != XST_SUCCESS) {
        return XST_FAILURE;
    }
    usleep(500000);
    adda_ctrl_dump("AD9643 pattern OFF");

    return XST_SUCCESS;
}
