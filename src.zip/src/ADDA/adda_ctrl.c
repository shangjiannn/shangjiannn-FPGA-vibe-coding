#include "adda_ctrl.h"

#include "xil_io.h"
#include "xil_printf.h"
#include "sleep.h"

#define ADDA_POLL_TIMEOUT 1000000U

static u32 g_current_profile = ADDA_PROFILE_DEFAULT;
static bool g_adc_test_mode = false;

u32 adda_ctrl_read(u32 offset)
{
    return Xil_In32(ADDA_BASEADDR + offset);
}

void adda_ctrl_write(u32 offset, u32 value)
{
    Xil_Out32(ADDA_BASEADDR + offset, value);
}

static int wait_status_set(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_ctrl_read(ADDA_REG_STATUS);
        if ((status & mask) == mask) {
            return XST_SUCCESS;
        }
        usleep(10);
    }

    return XST_FAILURE;
}

static int wait_status_clear(u32 mask, u32 timeout)
{
    while (timeout--) {
        u32 status = adda_ctrl_read(ADDA_REG_STATUS);
        if ((status & mask) == 0U) {
            return XST_SUCCESS;
        }
        usleep(10);
    }

    return XST_FAILURE;
}

void adda_ctrl_snapshot(adda_snapshot_t *s)
{
    if (s == NULL) {
        return;
    }

    s->control        = adda_ctrl_read(ADDA_REG_CONTROL);
    s->status         = adda_ctrl_read(ADDA_REG_STATUS);
    s->device_sel     = adda_ctrl_read(ADDA_REG_DEVICE_SEL);
    s->clock_profile  = adda_ctrl_read(ADDA_REG_CLOCK_PROFILE);
    s->adc_status     = adda_ctrl_read(ADDA_REG_ADC_STATUS);
    s->clock_status   = adda_ctrl_read(ADDA_REG_CLOCK_STATUS);
    s->debug_status   = adda_ctrl_read(ADDA_REG_DEBUG_STATUS);
    s->pattern_errcnt = adda_ctrl_read(ADDA_REG_PATTERN_ERRCNT);
    s->idelay_status  = adda_ctrl_read(ADDA_REG_IDELAY_STATUS);
}

void adda_ctrl_dump(const char *tag)
{
    adda_snapshot_t s;
    adda_ctrl_snapshot(&s);

    if (tag == NULL) {
        tag = "ADDA";
    }

    xil_printf("\r\n========== %s ==========\r\n", tag);
    xil_printf("BASEADDR        0x%08lx\r\n", (unsigned long)ADDA_BASEADDR);
    xil_printf("CONTROL         0x%08lx\r\n", (unsigned long)s.control);
    xil_printf("STATUS          0x%08lx\r\n", (unsigned long)s.status);
    xil_printf("DEVICE_SEL      0x%08lx\r\n", (unsigned long)s.device_sel);
    xil_printf("CLOCK_PROFILE   0x%08lx\r\n", (unsigned long)s.clock_profile);
    xil_printf("ADC_STATUS      0x%08lx\r\n", (unsigned long)s.adc_status);
    xil_printf("CLOCK_STATUS    0x%08lx\r\n", (unsigned long)s.clock_status);
    xil_printf("DEBUG_STATUS    0x%08lx\r\n", (unsigned long)s.debug_status);
    xil_printf("PATTERN_ERRCNT  0x%08lx\r\n", (unsigned long)s.pattern_errcnt);
    xil_printf("IDELAY_STATUS   0x%08lx\r\n", (unsigned long)s.idelay_status);

    xil_printf("Decoded STATUS: busy=%d err=%d init_done=%d manual_done=%d profile_busy=%d profile_done=%d profile_err=%d clk_lock=%d rst_done=%d\r\n",
               !!(s.status & ADDA_STATUS_SPI_BUSY),
               !!(s.status & ADDA_STATUS_SPI_ERROR),
               !!(s.status & ADDA_STATUS_INIT_DONE),
               !!(s.status & ADDA_STATUS_MANUAL_DONE),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_BUSY),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_DONE),
               !!(s.status & ADDA_STATUS_CLOCK_PROFILE_ERROR),
               !!(s.status & ADDA_STATUS_CLOCK_LOCKED),
               !!(s.status & ADDA_STATUS_RESET_DONE));

    xil_printf("Decoded ADC: idelay_ready=%d sample_valid=%d test_mode=%d aligned=%d pattern_err=%d errcnt=%lu\r\n",
               !!(s.adc_status & ADDA_ADC_STATUS_IDELAY_READY),
               !!(s.adc_status & ADDA_ADC_STATUS_SAMPLE_VALID),
               !!(s.adc_status & ADDA_ADC_STATUS_TEST_MODE_EN),
               !!(s.adc_status & ADDA_ADC_STATUS_DATA_ALIGNED),
               !!(s.adc_status & ADDA_ADC_STATUS_PATTERN_ERROR),
               (unsigned long)((s.adc_status & ADDA_ADC_STATUS_ERRCNT_MASK) >> ADDA_ADC_STATUS_ERRCNT_SHIFT));

    xil_printf("Applied profile = %lu, sample_rate_label = %lu Hz\r\n",
               (unsigned long)((s.clock_status & ADDA_CLOCK_STATUS_APPLIED_MASK) >> ADDA_CLOCK_STATUS_APPLIED_SHIFT),
               (unsigned long)adda_ctrl_current_sample_rate_hz());
}

void adda_ctrl_clear_sticky(void)
{
    adda_ctrl_write(ADDA_REG_CONTROL,
                    ADDA_CONTROL_AUTO_INIT_ENABLE |
                    (g_adc_test_mode ? ADDA_CONTROL_ADC_TEST_MODE_EN : 0U) |
                    ADDA_CONTROL_CLEAR_STICKY);
    usleep(100);
}

int adda_ctrl_start_default_init(void)
{
    xil_printf("\r\nADDA: start default AD9516 -> AD9122 -> AD9643 init...\r\n");

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_CONTROL,
                    ADDA_CONTROL_AUTO_INIT_ENABLE |
                    (g_adc_test_mode ? ADDA_CONTROL_ADC_TEST_MODE_EN : 0U) |
                    ADDA_CONTROL_START_DEFAULT_INIT);

    if (wait_status_set(ADDA_STATUS_INIT_DONE, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: default init timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    if (adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: default init SPI error, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    g_current_profile = ADDA_PROFILE_DEFAULT;
    xil_printf("ADDA: default init done.\r\n");
    return XST_SUCCESS;
}

int adda_ctrl_apply_profile(u32 profile, bool adc_test_mode_enable)
{
    u32 control;

    if (profile > ADDA_PROFILE_HIGH) {
        xil_printf("ADDA ERROR: invalid profile %lu\r\n", (unsigned long)profile);
        return XST_FAILURE;
    }

    g_adc_test_mode = adc_test_mode_enable;

    control = ADDA_CONTROL_AUTO_INIT_ENABLE | ADDA_CONTROL_APPLY_CLOCK_PROFILE;
    if (g_adc_test_mode) {
        control |= ADDA_CONTROL_ADC_TEST_MODE_EN;
    }

    xil_printf("\r\nADDA: apply profile %lu, adc_test_mode=%d\r\n",
               (unsigned long)profile,
               g_adc_test_mode ? 1 : 0);

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_CLOCK_PROFILE, profile & 0xFU);
    usleep(10);
    adda_ctrl_write(ADDA_REG_CONTROL, control);

    if (wait_status_clear(ADDA_STATUS_CLOCK_PROFILE_BUSY, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: profile busy timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    u32 status = adda_ctrl_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_CLOCK_PROFILE_ERROR) {
        xil_printf("ADDA ERROR: profile apply error, STATUS=0x%08lx CLOCK_STATUS=0x%08lx\r\n",
                   (unsigned long)status,
                   (unsigned long)adda_ctrl_read(ADDA_REG_CLOCK_STATUS));
        return XST_FAILURE;
    }

    if ((status & ADDA_STATUS_CLOCK_PROFILE_DONE) == 0U) {
        xil_printf("ADDA ERROR: profile done not set, STATUS=0x%08lx CLOCK_STATUS=0x%08lx\r\n",
                   (unsigned long)status,
                   (unsigned long)adda_ctrl_read(ADDA_REG_CLOCK_STATUS));
        return XST_FAILURE;
    }

    g_current_profile = profile;
    xil_printf("ADDA: profile %lu apply done.\r\n", (unsigned long)profile);
    return XST_SUCCESS;
}

int adda_ctrl_set_sample_profile(adda_sample_profile_t profile)
{
    return adda_ctrl_apply_profile((u32)profile, false);
}

int adda_ctrl_set_ad9643_test_pattern(bool enable)
{
    return adda_ctrl_apply_profile(g_current_profile, enable);
}

int adda_ctrl_select_device(u32 device)
{
    if (device > ADDA_DEVICE_AD9643) {
        return XST_FAILURE;
    }

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_DEVICE_SEL, device);
    usleep(10);

    if (adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: device select failed, device=%lu STATUS=0x%08lx\r\n",
                   (unsigned long)device,
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}

int adda_ctrl_manual_spi_write(u32 device, u32 addr, u32 data)
{
    xil_printf("\r\nADDA: manual SPI write dev=%lu addr=0x%04lx data=0x%02lx\r\n",
               (unsigned long)device,
               (unsigned long)addr,
               (unsigned long)data);

    if (adda_ctrl_select_device(device) != XST_SUCCESS) {
        return XST_FAILURE;
    }

    adda_ctrl_clear_sticky();
    adda_ctrl_write(ADDA_REG_SPI_ADDR, addr & 0x1FFFU);
    adda_ctrl_write(ADDA_REG_SPI_WDATA, data & 0xFFU);
    adda_ctrl_write(ADDA_REG_SPI_CMD, ADDA_SPI_CMD_MANUAL_WRITE);

    if (wait_status_clear(ADDA_STATUS_SPI_BUSY, ADDA_POLL_TIMEOUT) != XST_SUCCESS) {
        xil_printf("ADDA ERROR: manual SPI busy timeout, STATUS=0x%08lx\r\n",
                   (unsigned long)adda_ctrl_read(ADDA_REG_STATUS));
        return XST_FAILURE;
    }

    u32 status = adda_ctrl_read(ADDA_REG_STATUS);

    if (status & ADDA_STATUS_SPI_ERROR) {
        xil_printf("ADDA ERROR: manual SPI error, STATUS=0x%08lx\r\n", (unsigned long)status);
        return XST_FAILURE;
    }

    if ((status & ADDA_STATUS_MANUAL_DONE) == 0U) {
        xil_printf("ADDA ERROR: manual done not set, STATUS=0x%08lx\r\n", (unsigned long)status);
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}

float adda_ctrl_profile_sample_rate_hz(u32 profile)
{
    switch (profile) {
    case ADDA_PROFILE_DEFAULT:
        return ADDA_PROFILE0_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_LOW:
        return ADDA_PROFILE1_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_MID:
        return ADDA_PROFILE2_SAMPLE_RATE_HZ;
    case ADDA_PROFILE_HIGH:
        return ADDA_PROFILE3_SAMPLE_RATE_HZ;
    default:
        return ADDA_PROFILE0_SAMPLE_RATE_HZ;
    }
}

float adda_ctrl_current_sample_rate_hz(void)
{
    return adda_ctrl_profile_sample_rate_hz(g_current_profile);
}

u32 adda_ctrl_current_profile(void)
{
    return g_current_profile;
}

int adda_ctrl_basic_bringup(void)
{
    xil_printf("\r\n========================================\r\n");
    xil_printf(" ADDA / ADCTOP bring-up\r\n");
    xil_printf(" Base Address: 0x%08lx\r\n", (unsigned long)ADDA_BASEADDR);
    xil_printf("========================================\r\n");

    adda_ctrl_dump("power on");
    adda_ctrl_clear_sticky();

    if ((adda_ctrl_read(ADDA_REG_STATUS) & ADDA_STATUS_INIT_DONE) == 0U) {
        if (adda_ctrl_start_default_init() != XST_SUCCESS) {
            return XST_FAILURE;
        }
    } else {
        xil_printf("ADDA: auto init already done.\r\n");
    }

    if (adda_ctrl_select_device(ADDA_DEVICE_AD9643) != XST_SUCCESS) {
        return XST_FAILURE;
    }

    adda_ctrl_dump("after ADDA bring-up");
    return XST_SUCCESS;
}

int adda_ctrl_profile_sweep_test(bool return_to_default)
{
    xil_printf("\r\n==== ADDA profile sweep test ====\r\n");

    for (u32 profile = ADDA_PROFILE_DEFAULT; profile <= ADDA_PROFILE_HIGH; profile++) {
        if (adda_ctrl_apply_profile(profile, false) != XST_SUCCESS) {
            return XST_FAILURE;
        }

        adda_ctrl_dump("after profile apply");
        usleep(500000);
    }

    if (return_to_default) {
        if (adda_ctrl_apply_profile(ADDA_PROFILE_DEFAULT, false) != XST_SUCCESS) {
            return XST_FAILURE;
        }
    }

    xil_printf("ADDA: profile sweep done.\r\n");
    return XST_SUCCESS;
}

int adda_ctrl_ad9643_pattern_test(void)
{
    xil_printf("\r\n==== ADDA AD9643 ramp pattern test ====\r\n");

    if (adda_ctrl_set_ad9643_test_pattern(true) != XST_SUCCESS) {
        return XST_FAILURE;
    }
    usleep(500000);
    adda_ctrl_dump("AD9643 pattern ON");

    if (adda_ctrl_set_ad9643_test_pattern(false) != XST_SUCCESS) {
        return XST_FAILURE;
    }
    usleep(500000);
    adda_ctrl_dump("AD9643 pattern OFF");

    return XST_SUCCESS;
}
