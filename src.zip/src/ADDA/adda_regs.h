#ifndef ADDA_REGS_H
#define ADDA_REGS_H

#include "xparameters.h"
#include "xil_types.h"

/*
 * ADDA_BASEADDR selection.
 * Prefer the generated xparameters.h macro from the current Vivado/Vitis platform.
 * If your IP instance name is different, add its BASEADDR macro here.
 */
#ifndef ADDA_BASEADDR

#ifdef XPAR_ADDA_PS_CTRL_0_S00_AXI_BASEADDR
#define ADDA_BASEADDR XPAR_ADDA_PS_CTRL_0_S00_AXI_BASEADDR

#elif defined(XPAR_ADDA_PS_CTRL_0_BASEADDR)
#define ADDA_BASEADDR XPAR_ADDA_PS_CTRL_0_BASEADDR

#elif defined(XPAR_ADDA_TOP_0_S00_AXI_BASEADDR)
#define ADDA_BASEADDR XPAR_ADDA_TOP_0_S00_AXI_BASEADDR

#elif defined(XPAR_ADDA_TOP_0_BASEADDR)
#define ADDA_BASEADDR XPAR_ADDA_TOP_0_BASEADDR

#elif defined(XPAR_ADCTOP_0_S00_AXI_BASEADDR)
#define ADDA_BASEADDR XPAR_ADCTOP_0_S00_AXI_BASEADDR

#elif defined(XPAR_ADCTOP_0_BASEADDR)
#define ADDA_BASEADDR XPAR_ADCTOP_0_BASEADDR

#elif defined(XPAR_AD9643_0_S00_AXI_BASEADDR)
#define ADDA_BASEADDR XPAR_AD9643_0_S00_AXI_BASEADDR

#elif defined(XPAR_AD9643_0_BASEADDR)
#define ADDA_BASEADDR XPAR_AD9643_0_BASEADDR

#elif defined(XPAR_TOP_0_S00_AXI_BASEADDR)
#define ADDA_BASEADDR XPAR_TOP_0_S00_AXI_BASEADDR

#elif defined(XPAR_TOP_0_BASEADDR)
#define ADDA_BASEADDR XPAR_TOP_0_BASEADDR

#else
/* Current verified BD log showed ADDA base = 0x40000000. */
#define ADDA_BASEADDR 0x40000000U
#endif

#endif /* ADDA_BASEADDR */

/* Register offsets */
#define ADDA_REG_CONTROL           0x00U
#define ADDA_REG_STATUS            0x04U
#define ADDA_REG_DEVICE_SEL        0x08U
#define ADDA_REG_SPI_ADDR          0x0CU
#define ADDA_REG_SPI_WDATA         0x10U
#define ADDA_REG_SPI_RDATA         0x14U
#define ADDA_REG_SPI_CMD           0x18U
#define ADDA_REG_CLOCK_PROFILE     0x20U
#define ADDA_REG_ADC_MODE          0x24U
#define ADDA_REG_DAC_MODE          0x28U
#define ADDA_REG_DDS_FREQ_WORD     0x2CU
#define ADDA_REG_DDS_PHASE_WORD    0x30U
#define ADDA_REG_DDS_AMP           0x34U
#define ADDA_REG_ADC_STATUS        0x38U
#define ADDA_REG_CLOCK_STATUS      0x3CU
#define ADDA_REG_DEBUG_STATUS      0x40U
#define ADDA_REG_PATTERN_ERRCNT    0x44U
#define ADDA_REG_IDELAY_CTRL       0x48U
#define ADDA_REG_IDELAY_STATUS     0x4CU

/* CONTROL bits */
#define ADDA_CONTROL_START_DEFAULT_INIT  (1U << 0)
#define ADDA_CONTROL_SOFT_RESET          (1U << 1)
#define ADDA_CONTROL_AUTO_INIT_ENABLE    (1U << 2)
#define ADDA_CONTROL_ADC_TEST_MODE_EN    (1U << 3)
#define ADDA_CONTROL_CLEAR_STICKY        (1U << 4)
#define ADDA_CONTROL_APPLY_CLOCK_PROFILE (1U << 5)
#define ADDA_CONTROL_ADC_PATH_RESET      (1U << 6)
#define ADDA_CONTROL_DAC_PATH_RESET      (1U << 7)

/* STATUS bits */
#define ADDA_STATUS_SPI_BUSY             (1U << 0)
#define ADDA_STATUS_SPI_ERROR            (1U << 1)
#define ADDA_STATUS_INIT_DONE            (1U << 2)
#define ADDA_STATUS_SPI_DONE             (1U << 3)
#define ADDA_STATUS_MANUAL_DONE          (1U << 4)
#define ADDA_STATUS_CLOCK_PROFILE_BUSY   (1U << 5)
#define ADDA_STATUS_CLOCK_PROFILE_DONE   (1U << 6)
#define ADDA_STATUS_CLOCK_PROFILE_ERROR  (1U << 7)
#define ADDA_STATUS_ADC_IDELAY_READY     (1U << 8)
#define ADDA_STATUS_ADC_SAMPLE_VALID     (1U << 9)
#define ADDA_STATUS_ADC_DATA_ALIGNED     (1U << 10)
#define ADDA_STATUS_ADC_PATTERN_ERROR    (1U << 11)
#define ADDA_STATUS_CLOCK_LOCKED         (1U << 12)
#define ADDA_STATUS_RESET_DONE           (1U << 13)
#define ADDA_STATUS_SPI_STATE_MASK       0x00FF0000U
#define ADDA_STATUS_SPI_STATE_SHIFT      16U
#define ADDA_STATUS_SPI_INDEX_MASK       0xFF000000U
#define ADDA_STATUS_SPI_INDEX_SHIFT      24U

/* SPI_CMD bits */
#define ADDA_SPI_CMD_MANUAL_WRITE        (1U << 0)
#define ADDA_SPI_CMD_CLEAR_STICKY        (1U << 4)

/* Device select */
#define ADDA_DEVICE_AD9516               0U
#define ADDA_DEVICE_AD9122               1U
#define ADDA_DEVICE_AD9643               2U

/* CLOCK_STATUS bits */
#define ADDA_CLOCK_STATUS_INIT_DONE      (1U << 0)
#define ADDA_CLOCK_STATUS_PROFILE_BUSY   (1U << 1)
#define ADDA_CLOCK_STATUS_PROFILE_DONE   (1U << 2)
#define ADDA_CLOCK_STATUS_PROFILE_ERROR  (1U << 3)
#define ADDA_CLOCK_STATUS_CLOCK_LOCKED   (1U << 4)
#define ADDA_CLOCK_STATUS_RESET_DONE     (1U << 5)
#define ADDA_CLOCK_STATUS_APPLIED_MASK   0x000F0000U
#define ADDA_CLOCK_STATUS_APPLIED_SHIFT  16U

/* ADC_STATUS bits */
#define ADDA_ADC_STATUS_IDELAY_READY     (1U << 0)
#define ADDA_ADC_STATUS_SAMPLE_VALID     (1U << 1)
#define ADDA_ADC_STATUS_TEST_MODE_EN     (1U << 2)
#define ADDA_ADC_STATUS_DATA_ALIGNED     (1U << 3)
#define ADDA_ADC_STATUS_PATTERN_ERROR    (1U << 4)
#define ADDA_ADC_STATUS_ERRCNT_MASK      0xFFFF0000U
#define ADDA_ADC_STATUS_ERRCNT_SHIFT     16U

/* CLOCK_PROFILE readback fields */
#define ADDA_CLOCK_PROFILE_VALID         (1U << 8)
#define ADDA_CLOCK_PROFILE_PENDING       (1U << 9)
#define ADDA_CLOCK_PROFILE_APPLIED       (1U << 10)
#define ADDA_CLOCK_PROFILE_APPLIED_MASK  0x0000F000U
#define ADDA_CLOCK_PROFILE_APPLIED_SHIFT 12U

/* Profile index */
#define ADDA_PROFILE_DEFAULT             0U
#define ADDA_PROFILE_LOW                 1U
#define ADDA_PROFILE_MID                 2U
#define ADDA_PROFILE_HIGH                3U

#endif /* ADDA_REGS_H */
